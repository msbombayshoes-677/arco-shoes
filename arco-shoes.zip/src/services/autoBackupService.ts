import { dbService } from './storage';
import { CompanyInfo } from '../types';
import { getStoredDirectoryHandle, writeBackupToDirectoryHandle } from './folderStorage';
import { getApiUrl } from './apiConfig';

let isBackupRunning = false;
let backupIntervalId: any = null;

export interface AutoBackupEventDetail {
  filename: string;
  time: string;
  date: string;
  targetDbType: 'firebase' | 'mongodb';
  backupPath: string;
}

/**
 * Executes an automated backup for the active or configured database type.
 * Saves the JSON file via browser download and direct file system handle if granted.
 * Does NOT save or archive the downloaded backup file into the database collection.
 */
export async function executeAutoBackup(companyOverride?: CompanyInfo): Promise<{
  success: boolean;
  filename: string;
  targetDbType: 'firebase' | 'mongodb';
  message: string;
}> {
  if (isBackupRunning) {
    return {
      success: false,
      filename: '',
      targetDbType: 'firebase',
      message: 'Backup process is already running.',
    };
  }

  isBackupRunning = true;
  try {
    const comp = companyOverride || dbService.getCompanyInfo();
    const targetDbType: 'firebase' | 'mongodb' = comp.databaseType === 'mongodb' ? 'mongodb' : 'firebase';
    const activePath = (comp.backupPath || 'C:\\Backups\\ARCO_ERP').trim();

    const backupJson = dbService.exportDatabaseJsonForType(targetDbType);
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    const secs = String(now.getSeconds()).padStart(2, '0');

    const dateStr = `${year}-${month}-${day}`;
    const timeStr = `${hours}-${mins}`;
    const filename = `Backup_${targetDbType.toUpperCase()}_${dateStr}_TIME_${timeStr}.json`;

    // 1. Direct write into active folder directory handle if granted / connected
    let directFolderSaved = false;
    try {
      const dirHandle = await getStoredDirectoryHandle();
      if (dirHandle) {
        directFolderSaved = await writeBackupToDirectoryHandle(dirHandle, filename, backupJson);
        if (directFolderSaved) {
          console.info(`[Auto Backup] Successfully wrote ${filename} directly into active folder handle.`);
        }
      }
    } catch (fsErr) {
      console.warn('[Auto Backup] Filesystem direct write notice:', fsErr);
    }

    // 2. Try saving to local machine filesystem if local server is available
    try {
      await fetch(getApiUrl('/api/backup/save-local'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          backupPath: activePath,
          filename,
          content: backupJson,
        }),
      });
    } catch {
      // Local server save not available (remote environment)
    }

    // 3. Download backup file to browser download folder / system backup path
    if (typeof window !== 'undefined') {
      const blob = new Blob([backupJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    // 4. Mark lastAutoBackupDate, lastAutoBackupTime and lastBackupFilePath to record the executed slot
    const separator = activePath.includes('/') && !activePath.includes('\\') ? '/' : '\\';
    const cleanBaseDir = activePath.endsWith('\\') || activePath.endsWith('/') ? activePath.slice(0, -1) : activePath;
    const fullDownloadedFilePath = `${cleanBaseDir}${separator}${filename}`;

    const updatedCompany: CompanyInfo = {
      ...comp,
      backupPath: cleanBaseDir,
      lastBackupFilePath: fullDownloadedFilePath,
      lastAutoBackupDate: dateStr,
      lastAutoBackupTime: `${hours}:${mins}`,
      lastAutoBackupFilename: filename,
      lastAutoBackupPath: fullDownloadedFilePath,
      lastAutoBackupAt: now.toISOString(),
    };
    dbService.saveCompanyInfo(updatedCompany);

    // 4. Dispatch global event so active views can notify user
    if (typeof window !== 'undefined') {
      const detail: AutoBackupEventDetail = {
        filename,
        time: `${hours}:${mins}`,
        date: dateStr,
        targetDbType,
        backupPath: activePath,
      };
      window.dispatchEvent(new CustomEvent('arco:auto-backup-completed', { detail }));
    }

    console.info(`[Auto Backup] Successfully executed automated backup "${filename}" for ${targetDbType.toUpperCase()} at ${hours}:${mins} (Path: ${activePath})`);

    return {
      success: true,
      filename,
      targetDbType,
      message: `Automated backup completed at ${hours}:${mins}! Downloaded to active path "${activePath}".`,
    };
  } catch (err: any) {
    console.error('[Auto Backup Error]:', err);
    return {
      success: false,
      filename: '',
      targetDbType: 'firebase',
      message: `Error during auto backup: ${err?.message || err}`,
    };
  } finally {
    isBackupRunning = false;
  }
}

/**
 * Checks if current local time matches the configured 24-hr backup time
 * and triggers daily automated download if enabled.
 */
export function checkAndTriggerDailyAutoBackup(): void {
  try {
    const comp = dbService.getCompanyInfo();
    if (!comp.autoBackupEnabled || !comp.autoBackupTime) {
      return;
    }

    const now = new Date();
    const currentHH = String(now.getHours()).padStart(2, '0');
    const currentMM = String(now.getMinutes()).padStart(2, '0');
    const current24Time = `${currentHH}:${currentMM}`;

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const todayStr = `${year}-${month}-${day}`;

    // Normalize configured time (format HH:mm)
    const targetTime = comp.autoBackupTime.trim();

    // Check if matching target minute (24-hr clock)
    if (current24Time === targetTime) {
      // If a backup was already downloaded today for THIS EXACT time slot, don't repeat within the same minute.
      // However, if the time in 'Backup Time' box was changed to a new time today,
      // comp.lastAutoBackupTime !== targetTime, so it WILL download the file again at the newly specified time!
      const alreadyDownloadedForThisSlotToday =
        comp.lastAutoBackupDate === todayStr && comp.lastAutoBackupTime === targetTime;

      if (!alreadyDownloadedForThisSlotToday) {
        executeAutoBackup(comp);
      }
    }
  } catch (err) {
    console.warn('[Auto Backup Checker Notice]:', err);
  }
}

/**
 * Initializes the background timer checking every 15 seconds.
 */
export function initAutoBackupService(): () => void {
  if (typeof window === 'undefined') return () => {};

  if (backupIntervalId) {
    clearInterval(backupIntervalId);
  }

  // Initial check
  checkAndTriggerDailyAutoBackup();

  // Run periodic check every 15 seconds so we never miss the designated minute
  backupIntervalId = setInterval(() => {
    checkAndTriggerDailyAutoBackup();
  }, 15000);

  return () => {
    if (backupIntervalId) {
      clearInterval(backupIntervalId);
      backupIntervalId = null;
    }
  };
}
