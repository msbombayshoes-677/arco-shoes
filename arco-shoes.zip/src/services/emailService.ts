import { SalesInvoice, CompanyInfo } from '../types';
import { dbService } from './storage';
import { fetchApiWithFallback, getApiUrl } from './apiConfig';
import { collection, doc, setDoc } from 'firebase/firestore';
import { db, FIRESTORE_DATABASE_ID } from '../firebase';

export interface DayBookStatus {
  todayDaySales: number;
  totalSalesExchangeAmount: number;
  netDayCollection: number;
}

export interface EmailSendResult {
  success: boolean;
  message?: string;
  error?: string;
  isConfigIncomplete?: boolean;
  skipped?: boolean;
  recipientEmail?: string;
}

/**
 * Calculates Day Book figures matching the Day Book page logic
 */
export function getUpdatedDayBookStatus(targetDate: string): DayBookStatus {
  try {
    const allSales = dbService.getSales();
    const allSalesExchangeDesk = dbService.getSalesExchangeDeskRecords();

    // 1. Today Day Sales (all sales for targetDate)
    const todaySales = allSales
      .filter((s) => s.invoiceDate === targetDate)
      .reduce((sum, s) => sum + (Number(s.grandTotal) || 0), 0);

    // 2. Total Sales Exchange Amount (exchange desk records for targetDate)
    const dayDeskList = allSalesExchangeDesk.filter(
      (ed) =>
        (ed.billModifiedDate === targetDate ||
          ed.invoiceDate === targetDate ||
          (ed.createdAt && ed.createdAt.startsWith(targetDate))) &&
        !(ed.invoiceDate && ed.billModifiedDate && ed.invoiceDate === ed.billModifiedDate)
    );

    const totalSalesExchangeAmount = dayDeskList.reduce(
      (sum, ed) => sum + (Number(ed.netAmount) || 0),
      0
    );

    // 3. Net Day Collection = Today Day Sales + Total Sales Exchange Amount
    const netDayCollection = todaySales + totalSalesExchangeAmount;

    return {
      todayDaySales: Math.round(todaySales * 100) / 100,
      totalSalesExchangeAmount: Math.round(totalSalesExchangeAmount * 100) / 100,
      netDayCollection: Math.round(netDayCollection * 100) / 100,
    };
  } catch (err) {
    console.error('[DayBookStatus Error]:', err);
    return {
      todayDaySales: 0,
      totalSalesExchangeAmount: 0,
      netDayCollection: 0,
    };
  }
}

/**
 * Dispatch email directly via EmailJS REST API (100% client-side, zero backend required)
 */
export async function sendEmailViaEmailJs(
  company: CompanyInfo,
  templateParams: Record<string, any>
): Promise<{ success: boolean; message?: string; error?: string }> {
  const serviceId = (company.emailjsServiceId || '').trim();
  const templateId = (company.emailjsTemplateId || '').trim();
  const publicKey = (company.emailjsPublicKey || '').trim();

  if (!serviceId || !templateId || !publicKey) {
    return {
      success: false,
      error: 'EmailJS credentials incomplete. Please enter Service ID, Template ID, and Public Key in Settings.',
    };
  }

  try {
    const res = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        service_id: serviceId,
        template_id: templateId,
        user_id: publicKey,
        template_params: templateParams,
      }),
    });

    if (res.ok) {
      return {
        success: true,
        message: 'Email successfully sent via EmailJS client-side service.',
      };
    } else {
      const errText = await res.text();
      return {
        success: false,
        error: `EmailJS error (${res.status}): ${errText || 'Failed to send via EmailJS'}`,
      };
    }
  } catch (err: any) {
    return {
      success: false,
      error: `EmailJS network error: ${err?.message || 'Could not connect to EmailJS API'}`,
    };
  }
}

/**
 * Test 1: Test Primary Express SMTP Connection (Section 1)
 */
export async function testSmtpConnection(company: CompanyInfo): Promise<{ success: boolean; message: string }> {
  try {
    const effectiveSmtpEmail = (company.smtpEmail || company.email || '').trim();
    const effectiveReceivingEmail = (company.receivingEmail || company.email || company.smtpEmail || '').trim();
    const effectivePassword = (company.smtpPassword || '').trim();

    if (!effectiveSmtpEmail || !effectivePassword) {
      return {
        success: false,
        message: 'Please fill in Email and E-Password under EMAIL PURPOSE CONFIGURATION before testing.',
      };
    }

    const { response, isHtml, data } = await fetchApiWithFallback<any>('/api/test-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        smtpEmail: effectiveSmtpEmail,
        smtpPassword: effectivePassword,
        receivingEmail: effectiveReceivingEmail,
        email: company.email,
      }),
    });

    if (isHtml) {
      const isRemoteHost =
        typeof window !== 'undefined' &&
        window.location.hostname &&
        !window.location.hostname.includes('localhost') &&
        !window.location.hostname.includes('127.0.0.1');

      return {
        success: false,
        message: isRemoteHost
          ? 'Static web hosting (Firebase Hosting) detected. Static hosting does not run Node.js Express server code directly. Use Section 2 (Backend Server URL) or Section 3 (EmailJS) for deployed environments.'
          : 'Local Express backend server is not running on port 3000. Run "npm start" to launch local Node.js SMTP server.',
      };
    }

    if (!data) {
      return {
        success: false,
        message: 'Could not communicate with local SMTP service (invalid response).',
      };
    }

    if (!response.ok || !data.success) {
      return {
        success: false,
        message: data.error || data.message || 'Local SMTP authentication or connection test failed.',
      };
    }

    return {
      success: true,
      message: data.message || 'Local SMTP test succeeded! Test email sent successfully.',
    };
  } catch (err: any) {
    return {
      success: false,
      message: 'SMTP backend server is unavailable. Could not connect to local email service.',
    };
  }
}

/**
 * Test 2: Test Remote Custom Backend Server URL Connection (Section 2)
 */
export async function testCustomBackendConnection(company: CompanyInfo): Promise<{ success: boolean; message: string }> {
  const customUrl = (company.customBackendUrl || '').trim();

  if (!customUrl) {
    return {
      success: false,
      message: 'Please enter a valid Backend Server URL in Section 2 before testing.',
    };
  }

  // Ensure URL ends cleanly
  let targetUrl = customUrl.replace(/\/$/, '');
  if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
    targetUrl = 'https://' + targetUrl;
  }
  const endpoint = `${targetUrl}/api/test-email`;

  try {
    const effectiveSmtpEmail = (company.smtpEmail || company.email || '').trim();
    const effectiveReceivingEmail = (company.receivingEmail || company.email || company.smtpEmail || '').trim();
    const effectivePassword = (company.smtpPassword || '').trim();

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        smtpEmail: effectiveSmtpEmail,
        smtpPassword: effectivePassword,
        receivingEmail: effectiveReceivingEmail,
        email: company.email,
      }),
    });

    const contentType = res.headers.get('content-type') || '';
    if (contentType.includes('text/html')) {
      return {
        success: false,
        message: `Remote server at ${targetUrl} returned HTML (404/Not Found). Verify the Backend Server URL path.`,
      };
    }

    const data = await res.json();
    if (!res.ok || !data.success) {
      return {
        success: false,
        message: data?.error || data?.message || `Remote backend responded with error status (${res.status}).`,
      };
    }

    return {
      success: true,
      message: data.message || `Remote backend test succeeded! Test email sent via ${targetUrl}.`,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Could not reach remote backend at ${targetUrl}: ${err?.message || 'Network error'}`,
    };
  }
}

/**
 * Test 3: Test EmailJS Client-Side Connection (Section 3)
 */
export async function testEmailJsConnection(company: CompanyInfo): Promise<{ success: boolean; message: string }> {
  const serviceId = (company.emailjsServiceId || '').trim();
  const templateId = (company.emailjsTemplateId || '').trim();
  const publicKey = (company.emailjsPublicKey || '').trim();

  if (!serviceId || !templateId || !publicKey) {
    return {
      success: false,
      message: 'Please fill in Service ID, Template ID, and Public Key under EmailJS section before testing.',
    };
  }

  const res = await sendEmailViaEmailJs(company, {
    to_email: company.receivingEmail || company.email || 'arcoshoesco@gmail.com',
    from_name: company.companyName || 'ARCO SHOES',
    subject: 'ARCO Shoes ERP - EmailJS Connection Test Successful',
    message: 'EmailJS client-side direct email delivery is tested and working perfectly!',
  });

  if (res.success) {
    return {
      success: true,
      message: 'EmailJS test email sent successfully directly from browser!',
    };
  } else {
    return {
      success: false,
      message: res.error || 'EmailJS test failed.',
    };
  }
}

/**
 * Generates identical HTML markup for the invoice email with TOTAL column and Sub Totals
 */
export function generateInvoiceEmailHtml(
  invoice: SalesInvoice,
  company: CompanyInfo,
  dayBookStatus: DayBookStatus,
  isModifiedBill?: boolean
): string {
  const companyName = company?.companyName || 'ARCO SHOES Co';
  const companyAddress =
    [company?.addressLine1, company?.addressLine2, company?.city, company?.state, company?.pincode]
      .filter(Boolean)
      .join(', ') || 'Court Road, Anantnag, Kashmir';
  const companyGstin = company?.gstin || invoice.customerGstin || '';
  const companyPhone = company?.phone || company?.mobile || '';

  let sumQty = 0;
  let sumRate = 0;
  let sumDiscount = 0;
  let sumGst = 0;
  let sumAmount = 0;
  let sumTotal = 0;

  const itemsHtml = (invoice.items || [])
    .map((item: any, idx: number) => {
      const rateNum = Number(item.rate || item.mrp || 0);
      const rate = rateNum.toFixed(2);
      const qty = Number(item.quantity || 1);
      const discountNum = Number(
        item.discountAmount !== undefined && item.discountAmount !== null
          ? item.discountAmount
          : (item.discountPercent ? (Number(item.rate || 0) * qty * Number(item.discountPercent)) / 100 : 0)
      );
      const discount = discountNum.toFixed(2);
      const gstRate = item.taxPercent || item.gstRate || 0;
      const totalTaxNum = Number(
        item.taxAmount !== undefined && item.taxAmount !== null
          ? item.taxAmount
          : (Number(item.cgstAmount || 0) + Number(item.sgstAmount || 0) + Number(item.igstAmount || 0))
      );
      const totalTax = totalTaxNum.toFixed(2);

      // Amount column (taxable amount before GST)
      const amountNum = Number(
        item.taxableAmount !== undefined && item.taxableAmount !== null
          ? item.taxableAmount
          : (item.grossAmount ? Number(item.grossAmount) - discountNum : (Number(item.rate || 0) * qty - discountNum))
      );
      const amount = amountNum.toFixed(2);

      // TOTAL column is the total of 'GST' and 'AMOUNT'
      const totalNum = Number((amountNum + totalTaxNum).toFixed(2));
      const total = totalNum.toFixed(2);

      sumQty += qty;
      sumRate += rateNum;
      sumDiscount += discountNum;
      sumGst += totalTaxNum;
      sumAmount += amountNum;
      sumTotal += totalNum;

      return `
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 10px 8px; text-align: center; color: #475569;">${idx + 1}</td>
          <td style="padding: 10px 8px; color: #0f172a; font-weight: 500;">
            ${item.itemName || item.name || 'Footwear Item'}
            ${item.barcode ? `<div style="font-size: 11px; color: #64748b; font-family: monospace;">Barcode: ${item.barcode}</div>` : ''}
            ${item.size ? `<span style="font-size: 11px; color: #475569; background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">Size: ${item.size}</span>` : ''}
          </td>
          <td style="padding: 10px 8px; text-align: center; color: #0f172a; font-weight: 600;">${qty}</td>
          <td style="padding: 10px 8px; text-align: right; color: #334155;">₹${rate}</td>
          <td style="padding: 10px 8px; text-align: right; color: #64748b;">₹${discount}</td>
          <td style="padding: 10px 8px; text-align: right; color: #64748b;">${gstRate}% (₹${totalTax})</td>
          <td style="padding: 10px 8px; text-align: right; color: #334155; font-weight: 600;">₹${amount}</td>
          <td style="padding: 10px 8px; text-align: right; color: #0f172a; font-weight: 700;">₹${total}</td>
        </tr>
      `;
    })
    .join('');

  const subtotalQty = sumQty;
  const subtotalRate = sumRate.toFixed(2);
  const subtotalDiscount = sumDiscount.toFixed(2);
  const subtotalGst = sumGst.toFixed(2);
  const subtotalAmount = sumAmount.toFixed(2);
  const subtotalTotal = sumTotal.toFixed(2);

  const grandTotal = Number(invoice.grandTotal || 0).toFixed(2);
  const todaySales = Number(dayBookStatus?.todayDaySales || 0).toFixed(2);
  const totalExchange = Number(dayBookStatus?.totalSalesExchangeAmount || 0).toFixed(2);
  const netCollection = Number(dayBookStatus?.netDayCollection || 0).toFixed(2);

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 20px; background-color: #f8fafc; color: #1e293b; }
    .container { max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
    .header { background: #0f172a; color: #ffffff; padding: 28px 24px; text-align: center; }
    .header h1 { margin: 0; font-size: 24px; font-weight: 800; letter-spacing: 0.5px; color: #f8fafc; }
    .header h2 { margin: 6px 0 0 0; font-size: 14px; font-weight: 600; color: #cbd5e1; text-transform: uppercase; letter-spacing: 1px; }
    .content { padding: 24px; }
    .section-title { font-size: 15px; font-weight: 700; color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 6px; margin: 20px 0 12px 0; text-transform: uppercase; letter-spacing: 0.5px; }
    .details-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    .details-table td { padding: 6px 0; font-size: 13px; vertical-align: top; }
    .details-table .label { width: 38%; color: #64748b; font-weight: 500; }
    .details-table .value { width: 62%; color: #0f172a; font-weight: 600; }
    .items-table { width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 12px; }
    .items-table th { background: #f1f5f9; color: #475569; padding: 10px 8px; text-align: left; font-weight: 700; border-bottom: 2px solid #cbd5e1; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; }
    .net-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; margin: 20px 0; }
    .net-label { font-size: 16px; font-weight: 700; color: #166534; }
    .net-value { font-size: 22px; font-weight: 800; color: #15803d; }
    .daybook-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin: 24px 0 16px 0; }
    .daybook-title { font-size: 14px; font-weight: 700; color: #0f172a; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px dashed #cbd5e1; padding-bottom: 6px; }
    .daybook-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 13px; }
    .daybook-label { color: #475569; font-weight: 500; }
    .daybook-val { color: #0f172a; font-weight: 700; }
    .footer { text-align: center; padding: 16px; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; background: #fafafa; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${companyName.toUpperCase()}</h1>
      <h2>${isModifiedBill ? 'Tax Invoice / Retail Bill (Modified / Updated)' : 'Tax Invoice / Retail Bill'}</h2>
      ${isModifiedBill ? `<div style="display: inline-block; background: #4f46e5; color: #ffffff; padding: 4px 12px; border-radius: 9999px; font-size: 11px; font-weight: 700; margin-top: 6px; letter-spacing: 0.5px;">BILL MODIFIED / UPDATED</div>` : ''}
      ${companyAddress ? `<p style="margin: 6px 0 0 0; font-size: 12px; color: #94a3b8;">${companyAddress} ${companyPhone ? ' | Tel: ' + companyPhone : ''}</p>` : ''}
      ${companyGstin ? `<p style="margin: 4px 0 0 0; font-size: 11px; color: #94a3b8;">GSTIN: ${companyGstin}</p>` : ''}
    </div>

    <div class="content">
      <div class="section-title">Invoice Details</div>
      <table class="details-table">
        <tr>
          <td class="label">Customer Invoice Number:</td>
          <td class="value">${invoice.invoiceNo}</td>
        </tr>
        <tr>
          <td class="label">Invoice Date:</td>
          <td class="value">${invoice.invoiceDate}</td>
        </tr>
        ${invoice.billModifiedDate ? `
        <tr>
          <td class="label">Bill Modified Date:</td>
          <td class="value" style="color: #7c3aed; font-weight: 700;">${invoice.billModifiedDate}</td>
        </tr>` : ''}
        <tr>
          <td class="label">Customer Name:</td>
          <td class="value">${invoice.customerName || 'Walk-in Customer'}</td>
        </tr>
        <tr>
          <td class="label">Customer Mobile Number:</td>
          <td class="value">${invoice.customerMobile || 'N/A'}</td>
        </tr>
        ${invoice.paymentMode ? `
        <tr>
          <td class="label">Payment Mode:</td>
          <td class="value">${invoice.paymentMode}</td>
        </tr>` : ''}
      </table>

      <div class="section-title">Bill Items</div>
      <table class="items-table">
        <thead>
          <tr>
            <th style="width: 35px; text-align: center;">S.No.</th>
            <th>Item</th>
            <th style="text-align: center;">Qty</th>
            <th style="text-align: right;">Rate</th>
            <th style="text-align: right;">Discount</th>
            <th style="text-align: right;">GST</th>
            <th style="text-align: right;">Amount</th>
            <th style="text-align: right;">TOTAL</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHtml}
        </tbody>
        <tfoot>
          <tr style="border-top: 2px solid #cbd5e1; background: #f8fafc; font-weight: 700; color: #0f172a;">
            <td colspan="2" style="padding: 10px 8px; text-align: right; font-weight: 700; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; color: #475569;">Sub Total:</td>
            <td style="padding: 10px 8px; text-align: center; color: #0f172a; font-weight: 700;">${subtotalQty}</td>
            <td style="padding: 10px 8px; text-align: right; color: #334155; font-weight: 700;">₹${subtotalRate}</td>
            <td style="padding: 10px 8px; text-align: right; color: #64748b;">₹${subtotalDiscount}</td>
            <td style="padding: 10px 8px; text-align: right; color: #64748b;">₹${subtotalGst}</td>
            <td style="padding: 10px 8px; text-align: right; color: #334155; font-weight: 700;">₹${subtotalAmount}</td>
            <td style="padding: 10px 8px; text-align: right; color: #0f172a; font-weight: 800;">₹${subtotalTotal}</td>
          </tr>
        </tfoot>
      </table>

      <div class="net-box">
        <span class="net-label">Net Amount Payable:</span>
        <span class="net-value">₹${grandTotal}</span>
      </div>

      <div class="daybook-box">
        <div class="daybook-title">Day Book Status (${invoice.billModifiedDate || invoice.invoiceDate})</div>
        <div class="daybook-row">
          <span class="daybook-label">Today Day Sales:</span>
          <span class="daybook-val">₹${todaySales}</span>
        </div>
        <div class="daybook-row">
          <span class="daybook-label">Total Sales Exchange Amount:</span>
          <span class="daybook-val">₹${totalExchange}</span>
        </div>
        <div class="daybook-row" style="border-top: 1px solid #e2e8f0; margin-top: 6px; padding-top: 8px;">
          <span class="daybook-label" style="font-weight: 700; color: #0f172a;">Net Day Collection:</span>
          <span class="daybook-val" style="color: #0f766e; font-size: 14px;">₹${netCollection}</span>
        </div>
      </div>
    </div>

    <div class="footer">
      This email is automatically generated by the billing system.
    </div>
  </div>
</body>
</html>
  `;
}

/**
 * Generates plain-text fallback format for the invoice email
 */
export function generateInvoiceEmailText(
  invoice: SalesInvoice,
  company: CompanyInfo,
  dayBookStatus: DayBookStatus,
  isModifiedBill?: boolean
): string {
  const companyName = company?.companyName || 'ARCO SHOES Co';
  let sumQty = 0;
  let sumRate = 0;
  let sumDiscount = 0;
  let sumGst = 0;
  let sumAmount = 0;
  let sumTotal = 0;

  const itemsLines = (invoice.items || [])
    .map((item: any, idx: number) => {
      const rateNum = Number(item.rate || item.mrp || 0);
      const qty = Number(item.quantity || 1);
      const discountNum = Number(
        item.discountAmount !== undefined && item.discountAmount !== null
          ? item.discountAmount
          : (item.discountPercent ? (rateNum * qty * Number(item.discountPercent)) / 100 : 0)
      );
      const totalTaxNum = Number(
        item.taxAmount !== undefined && item.taxAmount !== null
          ? item.taxAmount
          : (Number(item.cgstAmount || 0) + Number(item.sgstAmount || 0) + Number(item.igstAmount || 0))
      );
      const amountNum = Number(
        item.taxableAmount !== undefined && item.taxableAmount !== null
          ? item.taxableAmount
          : (item.grossAmount ? Number(item.grossAmount) - discountNum : (rateNum * qty - discountNum))
      );
      const totalNum = Number((amountNum + totalTaxNum).toFixed(2));

      sumQty += qty;
      sumRate += rateNum;
      sumDiscount += discountNum;
      sumGst += totalTaxNum;
      sumAmount += amountNum;
      sumTotal += totalNum;

      return `${idx + 1}. ${item.itemName || item.name} | Qty: ${qty} | Rate: ₹${rateNum.toFixed(2)} | Disc: ₹${discountNum.toFixed(2)} | GST: ₹${totalTaxNum.toFixed(2)} | Amount: ₹${amountNum.toFixed(2)} | TOTAL: ₹${totalNum.toFixed(2)}`;
    })
    .join('\n');

  const grandTotal = Number(invoice.grandTotal || 0).toFixed(2);
  const todaySales = Number(dayBookStatus?.todayDaySales || 0).toFixed(2);
  const totalExchange = Number(dayBookStatus?.totalSalesExchangeAmount || 0).toFixed(2);
  const netCollection = Number(dayBookStatus?.netDayCollection || 0).toFixed(2);

  return `
${companyName}
${isModifiedBill ? 'Tax Invoice / Retail Bill (Modified / Updated)' : 'Tax Invoice / Retail Bill'}
===============================================
Customer Invoice Number: ${invoice.invoiceNo}
Invoice Date: ${invoice.invoiceDate}
${invoice.billModifiedDate ? `Bill Modified Date: ${invoice.billModifiedDate}\n` : ''}Customer Name: ${invoice.customerName || 'Walk-in Customer'}
Customer Mobile Number: ${invoice.customerMobile || 'N/A'}

Bill Items:
${itemsLines}
-----------------------------------------------
Sub Total: Qty: ${sumQty} | Rate: ₹${sumRate.toFixed(2)} | Disc: ₹${sumDiscount.toFixed(2)} | GST: ₹${sumGst.toFixed(2)} | Amount: ₹${sumAmount.toFixed(2)} | TOTAL: ₹${sumTotal.toFixed(2)}
===============================================
Net Amount Payable: ₹${grandTotal}
===============================================
Day Book Status (${invoice.billModifiedDate || invoice.invoiceDate}):
Today Day Sales: ₹${todaySales}
Total Sales Exchange Amount: ₹${totalExchange}
Net Day Collection: ₹${netCollection}
===============================================
This email is automatically generated by the billing system.
  `.trim();
}

/**
 * Dispatch invoice email via Firebase Cloud Functions HTTP Endpoint
 */
export async function sendEmailViaFirebaseCloudFunctions(
  invoice: SalesInvoice,
  company: CompanyInfo,
  options?: {
    isModified?: boolean;
    targetDate?: string;
  }
): Promise<EmailSendResult> {
  const isModifiedBill = Boolean(options?.isModified || invoice?.billModifiedDate);
  const effectiveDate =
    options?.targetDate || invoice.billModifiedDate || invoice.invoiceDate || new Date().toISOString().split('T')[0];
  const dayBookStatus = getUpdatedDayBookStatus(effectiveDate);

  const receiverEmail = (company.receivingEmail || company.email || 'arcoshoesco@gmail.com').trim();
  const senderEmail = (company.smtpEmail || company.email || 'arcoshoesco@gmail.com').trim();
  const senderPassword = (company.smtpPassword || '').trim();

  const payload = {
    invoice,
    isModified: isModifiedBill,
    dayBookStatus,
    companyInfo: {
      companyName: company.companyName,
      address: [company.addressLine1, company.addressLine2, company.city, company.state, company.pincode]
        .filter(Boolean)
        .join(', '),
      gstin: company.gstin,
      phone: company.phone || company.mobile,
    },
    emailConfig: {
      smtpEmail: senderEmail,
      smtpPassword: senderPassword,
      receivingEmail: receiverEmail,
      sendEmail: company.sendEmail ?? true,
    },
  };

  // Determine Cloud Function endpoint URL
  const targetUrl = company.cloudFunctionUrl && company.cloudFunctionUrl.trim()
    ? company.cloudFunctionUrl.trim()
    : '/api/send-invoice-email';

  try {
    const { response, isHtml, data } = await fetchApiWithFallback<any>(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!isHtml && data && data.success) {
      return {
        success: true,
        message: data.message || `Invoice email sent successfully via Cloud Function to ${receiverEmail}!`,
        recipientEmail: receiverEmail,
      };
    }

    if (!isHtml && data && data.success === false) {
      return {
        success: false,
        error: data.error || 'Cloud Function returned an error while dispatching email.',
        recipientEmail: receiverEmail,
      };
    }

    // Response was HTML (e.g. static Firebase Hosting fallback when Cloud Functions not deployed)
    const isLocalhost =
      typeof window !== 'undefined' &&
      (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

    if (isLocalhost) {
      // Localhost Express SMTP Fallback
      console.info('[EmailService] Falling back to local Express SMTP server...');
      const localRes = await fetchApiWithFallback<any>('/api/send-invoice-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!localRes.isHtml && localRes.data && localRes.data.success) {
        return {
          success: true,
          message: localRes.data.message || `Invoice email sent successfully via local server to ${receiverEmail}!`,
          recipientEmail: receiverEmail,
        };
      }
    }

    return {
      success: false,
      error:
        'Firebase Cloud Functions endpoint is not reachable or returned HTML. If deployed on Firebase Hosting, please deploy Cloud Functions (run "firebase deploy --only functions") OR enter your live Cloud Function Endpoint URL in Company Settings under FIREBASE CLOUD FUNCTIONS.',
      recipientEmail: receiverEmail,
    };
  } catch (err: any) {
    console.error('[Firebase Cloud Functions Email Error]:', err);
    return {
      success: false,
      error: `Could not send email via Cloud Functions: ${err?.message || 'Network error'}`,
    };
  }
}

/**
 * Tests Firebase Cloud Functions email delivery using Email Setup settings
 */
export async function testCloudFunctionsConnection(company: CompanyInfo): Promise<{ success: boolean; message: string }> {
  const receiverEmail = (company.receivingEmail || company.email || 'arcoshoesco@gmail.com').trim();
  const senderEmail = (company.smtpEmail || company.email || 'arcoshoesco@gmail.com').trim();
  const senderPassword = (company.smtpPassword || '').trim();

  if (!senderEmail || !senderPassword || !receiverEmail) {
    const missing: string[] = [];
    if (!senderEmail) missing.push('Email');
    if (!senderPassword) missing.push('E-Password');
    if (!receiverEmail) missing.push('Receiving Email');
    return {
      success: false,
      message: `Incomplete Email Setup: missing ${missing.join(', ')}. Please fill in Email Setup fields before testing Cloud Functions.`,
    };
  }

  const payload = {
    smtpEmail: senderEmail,
    smtpPassword: senderPassword,
    receivingEmail: receiverEmail,
  };

  const targetUrl = company.cloudFunctionUrl && company.cloudFunctionUrl.trim()
    ? company.cloudFunctionUrl.trim()
    : '/api/test-email';

  try {
    const { isHtml, data } = await fetchApiWithFallback<any>(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!isHtml && data && data.success) {
      return {
        success: true,
        message: data.message || `Firebase Cloud Function test email sent successfully to ${receiverEmail}!`,
      };
    }

    if (!isHtml && data && data.success === false) {
      return {
        success: false,
        message: data.error || 'Cloud Function returned an error during connection test.',
      };
    }

    // Response was HTML (static hosting page without active Cloud Function backend)
    const isLocalhost =
      typeof window !== 'undefined' &&
      (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

    if (isLocalhost) {
      // Localhost Express Fallback Test
      const localRes = await fetchApiWithFallback<any>('/api/test-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!localRes.isHtml && localRes.data && localRes.data.success) {
        return {
          success: true,
          message: localRes.data.message || `Test email sent successfully to ${receiverEmail}!`,
        };
      }
    }

    return {
      success: false,
      message:
        'Firebase Cloud Function endpoint returned HTML (Cloud Function not active on Firebase Hosting). Please deploy Cloud Functions (run "firebase deploy --only functions") OR enter your live Cloud Function Endpoint URL in Settings.',
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Firebase Cloud Function test failed: ${err?.message || 'Could not connect to Cloud Function endpoint'}`,
    };
  }
}

/**
 * Legacy compatibility wrapper for testEmailConnection
 */
export async function testEmailConnection(company: CompanyInfo): Promise<{ success: boolean; message: string }> {
  const mode = company.emailDispatchMode || 'smtp';
  if (mode === 'cloud_functions') {
    return testCloudFunctionsConnection(company);
  } else if (mode === 'emailjs') {
    return testEmailJsConnection(company);
  } else if (mode === 'custom_backend') {
    return testCustomBackendConnection(company);
  } else {
    return testSmtpConnection(company);
  }
}

/**
 * Sends an email for the saved invoice using the active email configuration
 */
export async function sendInvoiceEmail(
  invoice: SalesInvoice,
  company: CompanyInfo,
  options?: {
    isModified?: boolean;
    targetDate?: string;
  }
): Promise<EmailSendResult> {
  // Check if "Send E-Mail" option is disabled
  if (company.sendEmail === false) {
    return {
      success: false,
      skipped: true,
      message: 'Send E-Mail checkbox is disabled in Settings.',
    };
  }

  // Retrieve latest Day Book status for target date AFTER the bill has been saved
  const effectiveDate =
    options?.targetDate || invoice.billModifiedDate || invoice.invoiceDate || new Date().toISOString().split('T')[0];
  const dayBookStatus = getUpdatedDayBookStatus(effectiveDate);

  // 1. If "Use Cloud Functions" checkbox is checked, send using Firebase Cloud Functions with Email Setup settings
  if (company.useEmailCloudFunctions === true || company.emailDispatchMode === 'cloud_functions') {
    return await sendEmailViaFirebaseCloudFunctions(invoice, company, options);
  }

  // 2. Default: Send using Email Setup (Local/Express SMTP)
  try {
    const { response, isHtml, data } = await fetchApiWithFallback<any>('/api/send-invoice-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        invoice,
        isModified: options?.isModified ?? Boolean(invoice.billModifiedDate),
        dayBookStatus,
        companyInfo: {
          companyName: company.companyName,
          address: [company.addressLine1, company.addressLine2, company.city, company.state, company.pincode]
            .filter(Boolean)
            .join(', '),
          gstin: company.gstin,
          phone: company.phone || company.mobile,
        },
        emailConfig: {
          smtpEmail: company.smtpEmail || company.email,
          smtpPassword: company.smtpPassword,
          receivingEmail: company.receivingEmail || company.email,
          sendEmail: company.sendEmail ?? true,
        },
      }),
    });

    if (isHtml) {
      console.info('[EmailService] Static Firebase Hosting detected (received HTML). Automatically dispatching via Firebase Cloud Functions using Email Setup settings.');
      return await sendEmailViaFirebaseCloudFunctions(invoice, company, options);
    }

    if (!data || !data.success) {
      console.info('[EmailService] Primary server returned error. Failing over to Firebase Cloud Functions.');
      return await sendEmailViaFirebaseCloudFunctions(invoice, company, options);
    }

    return {
      success: Boolean(data.success),
      message: data.message,
      error: data.error,
      isConfigIncomplete: Boolean(data.isConfigIncomplete),
      skipped: Boolean(data.skipped),
      recipientEmail: (data.recipientEmail || company.receivingEmail || '').trim(),
    };
  } catch (err: any) {
    console.error('[EmailService Error]:', err);
    console.info('[EmailService] Primary server unavailable. Automatically dispatching via Firebase Cloud Functions using Email Setup settings.');
    return await sendEmailViaFirebaseCloudFunctions(invoice, company, options);
  }
}

/**
 * Saves email configuration securely to server-side memory & storage
 */
export async function syncEmailConfigToServer(company: Partial<CompanyInfo>): Promise<void> {
  try {
    await fetchApiWithFallback('/api/email-config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        smtpEmail: company.smtpEmail,
        smtpPassword: company.smtpPassword,
        receivingEmail: company.receivingEmail,
        sendEmail: company.sendEmail ?? true,
      }),
    });
  } catch (err) {
    console.warn('[SyncEmailConfigToServer] Error:', err);
  }
}
