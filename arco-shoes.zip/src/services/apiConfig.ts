/**
 * Centralized API URL and health configuration helper.
 * Supports development, production, custom VITE_API_URL, same-origin, and IIS reverse proxy environments.
 */

export function getApiUrl(endpoint: string): string {
  let customUrl = '';
  try {
    const storedComp = localStorage.getItem('arco_company_info');
    if (storedComp) {
      const parsed = JSON.parse(storedComp);
      if (parsed.customBackendUrl && typeof parsed.customBackendUrl === 'string') {
        customUrl = parsed.customBackendUrl.trim();
      }
    }
    if (!customUrl) {
      customUrl = (localStorage.getItem('arco_backend_api_url') || '').trim();
    }
  } catch (e) {}

  let baseUrl = (customUrl || import.meta.env.VITE_API_URL || '').trim().replace(/\/+$/, '');

  // Guard: If it's a dummy placeholder (e.g. 'your-backend-app.onrender.com' or 'example.com'), ignore it
  if (
    baseUrl.includes('your-backend-app') ||
    baseUrl.includes('example.com') ||
    baseUrl === 'https://' ||
    baseUrl === 'http://'
  ) {
    baseUrl = '';
  }

  // Guard: If running in production browser on a remote domain (e.g., Firebase Hosting *.web.app, *.firebaseapp.com, etc.),
  // do NOT let a stale or accidentally baked 'localhost:3000' break production API calls unless explicitly set in customUrl.
  if (!customUrl && typeof window !== 'undefined' && window.location && window.location.hostname) {
    const isLocalhostBrowser =
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1' ||
      window.location.hostname === '0.0.0.0';
    if (!isLocalhostBrowser && (baseUrl.includes('localhost') || baseUrl.includes('127.0.0.1'))) {
      baseUrl = '';
    }
  }

  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return baseUrl ? `${baseUrl}${cleanEndpoint}` : cleanEndpoint;
}

export interface ApiResponse<T = any> {
  response: Response;
  text: string;
  isHtml: boolean;
  data?: T;
}

/**
 * Resilient API fetch helper that automatically tries fallback candidates
 * (such as direct http://localhost:3000 or same-origin) if the primary fetch returns HTML (404/200 SPA fallback) or network error.
 */
export async function fetchApiWithFallback<T = any>(
  endpoint: string,
  options?: RequestInit
): Promise<ApiResponse<T>> {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;

  const candidateUrls: string[] = [];

  // 1. Primary configured API URL
  const primaryUrl = getApiUrl(cleanEndpoint);
  candidateUrls.push(primaryUrl);

  // 2. Additional candidate fallback URLs
  if (typeof window !== 'undefined' && window.location) {
    const isLocalhostBrowser =
      window.location.hostname === 'localhost' ||
      window.location.hostname === '127.0.0.1' ||
      window.location.hostname === '0.0.0.0';

    if (isLocalhostBrowser) {
      const local3000 = `http://localhost:3000${cleanEndpoint}`;
      if (!candidateUrls.includes(local3000)) candidateUrls.push(local3000);

      const local127 = `http://127.0.0.1:3000${cleanEndpoint}`;
      if (!candidateUrls.includes(local127)) candidateUrls.push(local127);
    }

    const sameOrigin = `${window.location.origin}${cleanEndpoint}`;
    if (!candidateUrls.includes(sameOrigin)) candidateUrls.push(sameOrigin);
  }

  let lastResponse: Response | null = null;
  let lastText = '';
  let lastIsHtml = false;

  for (const url of candidateUrls) {
    try {
      const res = await fetch(url, options);
      const text = await res.text();
      const isHtml =
        text.trim().startsWith('<') ||
        text.includes('<!DOCTYPE') ||
        text.includes('<!doctype') ||
        text.includes('<html');

      if (res.ok && !isHtml) {
        let data: any = undefined;
        try {
          data = JSON.parse(text);
        } catch (e) {}
        return { response: res, text, isHtml: false, data };
      }

      lastResponse = res;
      lastText = text;
      lastIsHtml = isHtml;

      // If response is valid JSON even if status is error (e.g. 400 Bad Request with JSON error), return it
      if (!isHtml && text.trim().startsWith('{')) {
        let data: any = undefined;
        try {
          data = JSON.parse(text);
        } catch (e) {}
        return { response: res, text, isHtml: false, data };
      }
    } catch (err) {
      // Continue to next candidate
    }
  }

  return {
    response: lastResponse || new Response(null, { status: 503 }),
    text: lastText,
    isHtml: lastIsHtml,
  };
}

export interface BackendHealthResponse {
  success: boolean;
  service?: string;
  status?: string;
  port?: number;
  timestamp?: string;
  message?: string;
  isHtmlResponse?: boolean;
}

export async function checkBackendHealth(): Promise<BackendHealthResponse> {
  try {
    const { response, text, isHtml, data } = await fetchApiWithFallback('/api/health', { method: 'GET' });

    if (isHtml) {
      return {
        success: false,
        isHtmlResponse: true,
        message:
          'Backend API server unreachable: Received an HTML webpage instead of an API response (200). In Firebase production, ensure Cloud Functions ("api") is deployed and firebase.json routes /api/** to function "api". In local development, ensure Node.js Express server is started and listening on port 3000.',
      };
    }

    if (response.ok && data && (data.success || data.status === 'ok' || data.status === 'running')) {
      return {
        success: true,
        service: data.service || 'SMTP Backend',
        status: data.status || 'running',
        port: data.port || 3000,
        timestamp: data.timestamp,
        message: 'Node.js Express backend is running and reachable.',
      };
    }

    return {
      success: false,
      message: (data && (data.error || data.message)) || `Backend health check failed with status ${response.status}`,
    };
  } catch (err: any) {
    return {
      success: false,
      message: `SMTP backend server is unavailable: ${err.message || 'Could not connect to API server'}.`,
    };
  }
}
