import { GoogleAuthProvider, signInWithPopup, User, onAuthStateChanged } from 'firebase/auth';
import { auth, firebaseConfig } from '../firebase';
import { dbService } from './storage';
import { auditService } from './auditService';

export const GOOGLE_DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
const GDRIVE_CONFIG_STORAGE_KEY = 'arco_gdrive_config_v2';
const GDRIVE_SESSION_TOKEN_KEY = 'arco_gdrive_session_token';
const GDRIVE_SESSION_EXP_KEY = 'arco_gdrive_session_exp';
const DEFAULT_FOLDER_NAME = 'ARCO_GST_Backups';

export interface GoogleDriveConfig {
  backupSource: 'firebase' | 'mongodb';
  folderName: string;
  folderId?: string;
  lastBackupAt?: string;
  lastBackupFilename?: string;
  lastBackupSource?: 'firebase' | 'mongodb';
  lastBackupStatus?: 'SUCCESS' | 'ERROR';
  lastBackupSize?: number;
  lastBackupFileId?: string;
  lastBackupWebViewLink?: string;
  connectedEmail?: string;
  connectedName?: string;
  connectedPhotoUrl?: string;
  autoConnect?: boolean;
}

export interface GoogleDriveUserInfo {
  email: string;
  name: string;
  photoUrl?: string;
}

export interface GoogleDriveFile {
  id: string;
  name: string;
  size?: string;
  createdTime?: string;
  modifiedTime?: string;
  webViewLink?: string;
}

export type BackupStep =
  | 'idle'
  | 'preparing'
  | 'creating_file'
  | 'connecting'
  | 'uploading'
  | 'completed'
  | 'error';

class GoogleDriveService {
  private cachedAccessToken: string | null = null;
  private tokenExpiresAt: number = 0;
  private config: GoogleDriveConfig;
  private listeners: Array<() => void> = [];
  private currentUser: User | null = null;
  private connectedUser: GoogleDriveUserInfo | null = null;

  constructor() {
    this.config = this.loadConfig();
    this.restoreSessionToken();
    if (typeof window !== 'undefined') {
      this.initAuthListener();
    }
  }

  private restoreSessionToken(): void {
    if (typeof window === 'undefined') return;
    try {
      const token = sessionStorage.getItem(GDRIVE_SESSION_TOKEN_KEY);
      const expStr = sessionStorage.getItem(GDRIVE_SESSION_EXP_KEY);
      if (token) {
        const exp = expStr ? Number(expStr) : 0;
        if (!exp || exp > Date.now()) {
          this.cachedAccessToken = token;
          this.tokenExpiresAt = exp || Date.now() + 3500 * 1000;
        } else {
          sessionStorage.removeItem(GDRIVE_SESSION_TOKEN_KEY);
          sessionStorage.removeItem(GDRIVE_SESSION_EXP_KEY);
        }
      }
    } catch {
      // Ignore sessionStorage errors
    }
  }

  private saveSessionToken(token: string, expiresInSec: number = 3500): void {
    this.cachedAccessToken = token;
    this.tokenExpiresAt = Date.now() + expiresInSec * 1000;
    try {
      sessionStorage.setItem(GDRIVE_SESSION_TOKEN_KEY, token);
      sessionStorage.setItem(GDRIVE_SESSION_EXP_KEY, String(this.tokenExpiresAt));
    } catch {
      // Ignore sessionStorage errors
    }
  }

  private clearSessionToken(): void {
    this.cachedAccessToken = null;
    this.tokenExpiresAt = 0;
    try {
      sessionStorage.removeItem(GDRIVE_SESSION_TOKEN_KEY);
      sessionStorage.removeItem(GDRIVE_SESSION_EXP_KEY);
    } catch {
      // Ignore
    }
  }

  private loadConfig(): GoogleDriveConfig {
    try {
      const raw = localStorage.getItem(GDRIVE_CONFIG_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.connectedEmail) {
          this.connectedUser = {
            email: parsed.connectedEmail,
            name: parsed.connectedName || parsed.connectedEmail.split('@')[0] || 'Google Account',
            photoUrl: parsed.connectedPhotoUrl || undefined,
          };
        }
        return {
          backupSource: 'firebase',
          folderName: DEFAULT_FOLDER_NAME,
          autoConnect: true,
          ...parsed,
        };
      }
    } catch (e) {
      console.warn('Failed to parse Google Drive config:', e);
    }
    return {
      backupSource: 'firebase',
      folderName: DEFAULT_FOLDER_NAME,
      autoConnect: true,
    };
  }

  public saveConfig(updated: Partial<GoogleDriveConfig>): void {
    this.config = { ...this.config, ...updated };
    if (this.config.connectedEmail) {
      this.connectedUser = {
        email: this.config.connectedEmail,
        name: this.config.connectedName || this.config.connectedEmail.split('@')[0] || 'Google Account',
        photoUrl: this.config.connectedPhotoUrl || undefined,
      };
    }
    try {
      localStorage.setItem(GDRIVE_CONFIG_STORAGE_KEY, JSON.stringify(this.config));
    } catch (e) {
      console.warn('Failed to save Google Drive config:', e);
    }
    this.notify();
  }

  public getConfig(): GoogleDriveConfig {
    return { ...this.config };
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach((cb) => {
      try {
        cb();
      } catch (err) {
        console.error('Error in gdrive subscriber:', err);
      }
    });
  }

  private initAuthListener(): void {
    onAuthStateChanged(auth, (user) => {
      this.currentUser = user;
      if (user?.email && user.email !== this.config.connectedEmail) {
        this.saveConfig({
          connectedEmail: user.email,
          connectedName: user.displayName || user.email,
          connectedPhotoUrl: user.photoURL || undefined,
          autoConnect: true,
        });
      }
      this.notify();
    });
  }

  public isConnected(): boolean {
    return Boolean(this.config.connectedEmail || this.cachedAccessToken);
  }

  public hasValidCachedToken(): boolean {
    return Boolean(this.cachedAccessToken && (!this.tokenExpiresAt || this.tokenExpiresAt > Date.now() + 10000));
  }

  public getConnectedUser(): GoogleDriveUserInfo | null {
    if (this.connectedUser) return this.connectedUser;
    if (this.currentUser) {
      return {
        email: this.currentUser.email || '',
        name: this.currentUser.displayName || this.currentUser.email || 'Google User',
        photoUrl: this.currentUser.photoURL || undefined,
      };
    }
    if (this.config.connectedEmail) {
      return {
        email: this.config.connectedEmail,
        name: this.config.connectedName || this.config.connectedEmail.split('@')[0] || 'Google Account',
        photoUrl: this.config.connectedPhotoUrl || undefined,
      };
    }
    return null;
  }

  public getCachedAccessToken(): string | null {
    return this.cachedAccessToken;
  }

  /**
   * Helper to ensure Google Identity Services client is ready in browser
   */
  private async ensureGisLoaded(): Promise<void> {
    if (typeof window === 'undefined') return;
    if ((window as any).google?.accounts?.oauth2) return;

    return new Promise((resolve) => {
      let attempts = 0;
      const checkInterval = setInterval(() => {
        attempts++;
        if ((window as any).google?.accounts?.oauth2 || attempts > 25) {
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);

      // Also dynamically inject script if not present
      if (!document.querySelector('script[src*="accounts.google.com/gsi/client"]')) {
        const script = document.createElement('script');
        script.src = 'https://accounts.google.com/gsi/client';
        script.async = true;
        script.defer = true;
        script.onload = () => {
          clearInterval(checkInterval);
          resolve();
        };
        script.onerror = () => {
          clearInterval(checkInterval);
          resolve();
        };
        document.head.appendChild(script);
      }
    });
  }

  /**
   * Request Access Token directly via Google Identity Services (GIS)
   */
  private async requestGisToken(
    clientId: string,
    scopes: string,
    prompt: string = '',
    hintEmail?: string
  ): Promise<{ accessToken: string; userInfo: GoogleDriveUserInfo }> {
    await this.ensureGisLoaded();

    if (!(window as any).google?.accounts?.oauth2) {
      throw new Error('Google Identity Services script not available.');
    }

    return new Promise((resolve, reject) => {
      try {
        const clientConfig: any = {
          client_id: clientId,
          scope: scopes,
          callback: async (response: any) => {
            if (response.error) {
              if (response.error === 'access_denied') {
                reject(new Error('Google Drive access was cancelled or permission was not granted.'));
                return;
              }
              reject(new Error(response.error_description || response.error || 'Google authentication failed.'));
              return;
            }
            if (!response.access_token) {
              reject(new Error('No access token returned from Google.'));
              return;
            }

            // Fetch profile info from Google Userinfo API
            let userInfo: GoogleDriveUserInfo = {
              email: hintEmail || this.config.connectedEmail || '',
              name: this.config.connectedName || 'Google Drive User',
              photoUrl: this.config.connectedPhotoUrl || undefined,
            };

            try {
              const infoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: { Authorization: `Bearer ${response.access_token}` },
              });
              if (infoRes.ok) {
                const uJson = await infoRes.json();
                userInfo = {
                  email: uJson.email || userInfo.email,
                  name: uJson.name || uJson.email || userInfo.name,
                  photoUrl: uJson.picture || userInfo.photoUrl,
                };
              }
            } catch {
              // Ignore profile fetch failure
            }

            resolve({ accessToken: response.access_token, userInfo });
          },
          error_callback: (err: any) => {
            if (err?.type === 'popup_closed') {
              reject(new Error('Google account selection window was closed by the user.'));
              return;
            }
            if (err?.type === 'popup_blocked') {
              reject(new Error('Google login popup was blocked by your browser. Please allow popups for this site.'));
              return;
            }
            reject(new Error(err?.message || 'Failed to authenticate Google Drive.'));
          },
        };

        if (prompt) {
          clientConfig.prompt = prompt;
        }
        if (hintEmail) {
          clientConfig.hint = hintEmail;
        }

        const client = (window as any).google.accounts.oauth2.initTokenClient(clientConfig);

        const requestParams: any = {};
        if (prompt) {
          requestParams.prompt = prompt;
        }
        if (hintEmail) {
          requestParams.hint = hintEmail;
        }

        client.requestAccessToken(requestParams);
      } catch (err: any) {
        reject(err);
      }
    });
  }

  /**
   * Ensures a valid Google Drive access token is available.
   * Re-uses existing valid token or silently obtains a new token for the connected account.
   */
  public async ensureValidAccessToken(forceAccountSelection = false): Promise<string> {
    if (
      this.cachedAccessToken &&
      !forceAccountSelection &&
      (!this.tokenExpiresAt || Date.now() < this.tokenExpiresAt - 60000)
    ) {
      return this.cachedAccessToken;
    }

    const clientId =
      (firebaseConfig as any).oAuthClientId ||
      '1081338356980-6b54vbtbms45iuesfttcrepv694nv5c4.apps.googleusercontent.com';
    const scopes = `${GOOGLE_DRIVE_SCOPE} https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email`;

    const targetEmail = this.config.connectedEmail;
    const promptVal = forceAccountSelection || !targetEmail ? 'select_account' : '';

    try {
      const { accessToken, userInfo } = await this.requestGisToken(
        clientId,
        scopes,
        promptVal,
        targetEmail
      );

      this.cachedAccessToken = accessToken;
      this.saveSessionToken(accessToken, 3500);
      this.connectedUser = userInfo;
      this.saveConfig({
        connectedEmail: userInfo.email || targetEmail,
        connectedName: userInfo.name,
        connectedPhotoUrl: userInfo.photoUrl,
        autoConnect: true,
      });
      this.notify();

      return accessToken;
    } catch (err: any) {
      if (forceAccountSelection) {
        throw err;
      }
      if (this.cachedAccessToken) {
        return this.cachedAccessToken;
      }
      throw err;
    }
  }

  /**
   * Connect Google Drive: opens the Google Account selection screen
   */
  public async connectGoogleDrive(forceAccountSelection = true): Promise<{ user: GoogleDriveUserInfo; accessToken: string }> {
    const accessToken = await this.ensureValidAccessToken(forceAccountSelection);
    const userInfo = this.getConnectedUser() || {
      email: this.config.connectedEmail || 'Authenticated Google User',
      name: this.config.connectedName || 'Google User',
    };

    auditService.log({
      action: 'LOGIN',
      entityType: 'SETTINGS',
      entityId: 'GOOGLE_DRIVE',
      entityName: 'Google Drive Connection',
      summary: `Connected Google Drive account: ${userInfo.email || 'Google User'}`,
    });

    return { user: userInfo, accessToken };
  }

  /**
   * Disconnect Google Drive
   */
  public async disconnectGoogleDrive(): Promise<void> {
    this.clearSessionToken();
    this.connectedUser = null;
    this.saveConfig({
      connectedEmail: undefined,
      connectedName: undefined,
      connectedPhotoUrl: undefined,
      autoConnect: false,
    });
    this.notify();

    auditService.log({
      action: 'UPDATE',
      entityType: 'SETTINGS',
      entityId: 'GOOGLE_DRIVE',
      entityName: 'Google Drive Disconnect',
      summary: 'Disconnected Google Drive integration.',
    });
  }

  /**
   * Test Google Drive Connection & Folder Accessibility
   */
  public async testConnection(): Promise<{
    success: boolean;
    message: string;
    folderId?: string;
    folderName?: string;
    userEmail?: string;
  }> {
    const accessToken = await this.ensureValidAccessToken(false);

    // 1. Verify User Profile & API Access
    const userRes = await fetch('https://www.googleapis.com/drive/v3/about?fields=user', {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!userRes.ok) {
      if (userRes.status === 401) {
        this.clearSessionToken();
        this.notify();
        throw new Error('Google Drive authorization session expired. Please reconnect your Google account.');
      }
      const errJson = await userRes.json().catch(() => ({}));
      throw new Error(errJson.error?.message || `Google Drive API error (${userRes.status}).`);
    }

    const userData = await userRes.json();
    const userEmail =
      userData.user?.emailAddress ||
      this.connectedUser?.email ||
      this.config.connectedEmail ||
      'Connected Account';

    // 2. Verify or Create Target Backup Folder
    const targetFolderName = this.config.folderName?.trim() || DEFAULT_FOLDER_NAME;
    const folder = await this.getOrCreateFolder(targetFolderName);

    return {
      success: true,
      message: `Google Drive connection successful! Account "${userEmail}" is connected and folder "${folder.name}" is accessible with write permissions.`,
      folderId: folder.id,
      folderName: folder.name,
      userEmail,
    };
  }

  /**
   * Find or create a folder in Google Drive
   */
  public async getOrCreateFolder(folderName: string): Promise<{ id: string; name: string }> {
    const accessToken = await this.ensureValidAccessToken(false);

    const cleanName = folderName.trim() || DEFAULT_FOLDER_NAME;
    const queryStr = `mimeType = 'application/vnd.google-apps.folder' and name = '${cleanName.replace(/'/g, "\\'")}' and trashed = false`;
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      queryStr
    )}&fields=files(id,name)&spaces=drive`;

    const searchRes = await fetch(searchUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!searchRes.ok) {
      if (searchRes.status === 401) {
        this.clearSessionToken();
        this.notify();
        throw new Error('Google Drive authorization expired. Please reconnect.');
      }
      const errJson = await searchRes.json().catch(() => ({}));
      throw new Error(errJson.error?.message || 'Failed to search Google Drive folders.');
    }

    const searchData = await searchRes.json();
    if (Array.isArray(searchData.files) && searchData.files.length > 0) {
      const folderId = searchData.files[0].id;
      this.saveConfig({ folderId, folderName: cleanName });
      return { id: folderId, name: cleanName };
    }

    // Create the folder
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: cleanName,
        mimeType: 'application/vnd.google-apps.folder',
      }),
    });

    if (!createRes.ok) {
      const errJson = await createRes.json().catch(() => ({}));
      throw new Error(errJson.error?.message || `Failed to create folder "${cleanName}" in Google Drive.`);
    }

    const folderData = await createRes.json();
    this.saveConfig({ folderId: folderData.id, folderName: cleanName });
    return { id: folderData.id, name: cleanName };
  }

  /**
   * List existing folders in user's Drive
   */
  public async listFolders(): Promise<Array<{ id: string; name: string }>> {
    if (!this.cachedAccessToken) return [];
    try {
      const accessToken = this.cachedAccessToken;
      const queryStr = `mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
      const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
        queryStr
      )}&fields=files(id,name)&pageSize=20&orderBy=name`;

      const res = await fetch(searchUrl, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (!res.ok) return [];
      const data = await res.json();
      return Array.isArray(data.files) ? data.files : [];
    } catch {
      return [];
    }
  }

  /**
   * List recent backup files in the configured folder
   */
  public async listBackupFiles(folderId?: string): Promise<GoogleDriveFile[]> {
    if (!this.cachedAccessToken) return [];
    try {
      const accessToken = this.cachedAccessToken;
      const targetFolderId = folderId || this.config.folderId;
      let queryStr = `trashed = false and mimeType = 'application/json'`;
      if (targetFolderId) {
        queryStr = `'${targetFolderId}' in parents and trashed = false`;
      }

      const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
        queryStr
      )}&fields=files(id,name,size,createdTime,modifiedTime,webViewLink)&pageSize=15&orderBy=createdTime desc`;

      const res = await fetch(searchUrl, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (!res.ok) return [];
      const data = await res.json();
      return Array.isArray(data.files) ? data.files : [];
    } catch {
      return [];
    }
  }

  /**
   * Generate complete database backup for specific source (Firebase or MongoDB)
   */
  public async generateBackupPayload(source: 'firebase' | 'mongodb'): Promise<{
    rawJson: string;
    filename: string;
    totalRecords: number;
    counts: Record<string, number>;
  }> {
    let rawDump: string;
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timeStr = now.toTimeString().slice(0, 8).replace(/:/g, '-');
    const sourcePrefix = source === 'firebase' ? 'Firebase' : 'MongoDB';
    const filename = `${sourcePrefix}_Backup_${dateStr}_${timeStr}.json`;

    if (source === 'mongodb') {
      // Fetch full MongoDB database from backend
      try {
        const comp = dbService.getCompanyInfo();
        const res = await fetch('/api/mongodb/get-app-data', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mongoUri: comp.mongoUri || 'mongodb://127.0.0.1:27017',
            dbName: comp.mongoDbName || 'arco_shoes_db',
          }),
        });

        if (res.ok) {
          const json = await res.json();
          if (json.success && json.data) {
            const data = json.data;
            const payload = {
              version: 'ARCO_GST_PORTABLE_V2.0',
              exportedAt: now.toISOString(),
              sourceDatabaseType: 'mongodb',
              databaseType: 'mongodb',
              company: data.company || dbService.getCompanyInfo(),
              items: data.items || [],
              customers: data.customers || [],
              suppliers: data.suppliers || [],
              sales: data.sales || [],
              salesReturns: data.sales_returns || [],
              salesExchanges: data.exchanges || [],
              salesExchangeDesk: data.exchange_desk || [],
              stockMovements: data.movements || [],
              customerCreditTxns: data.credit_txns || [],
              purchases: data.purchases || [],
              purchaseReturns: data.purchase_returns || [],
              receipts: data.receipts || [],
              payments: data.payments || [],
              adjustments: data.adjustments || [],
              ledgers: data.ledgers || [],
              security: data.security || dbService.getSecuritySettings(),
            };
            rawDump = JSON.stringify(payload, null, 2);
          } else {
            // Fallback to active dump if backend was offline
            rawDump = dbService.exportFullDatabase();
          }
        } else {
          rawDump = dbService.exportFullDatabase();
        }
      } catch {
        rawDump = dbService.exportFullDatabase();
      }
    } else {
      // Firebase export
      rawDump = dbService.exportFullDatabase();
    }

    const parsed = JSON.parse(rawDump);
    // Ensure source metadata is accurate
    parsed.sourceDatabaseType = source;
    parsed.databaseType = source;
    rawDump = JSON.stringify(parsed, null, 2);

    const counts = {
      items: (parsed.items || []).length,
      customers: (parsed.customers || []).length,
      suppliers: (parsed.suppliers || []).length,
      sales: (parsed.sales || []).length,
      purchases: (parsed.purchases || []).length,
      adjustments: (parsed.adjustments || []).length,
      ledgers: (parsed.ledgers || []).length,
    };

    const totalRecords = Object.values(counts).reduce((a, b) => a + b, 0);

    return { rawJson: rawDump, filename, totalRecords, counts };
  }

  /**
   * Execute full backup to Google Drive workflow with step callbacks
   */
  public async executeBackupToGoogleDrive(
    sourceOverride?: 'firebase' | 'mongodb',
    onProgress?: (step: BackupStep, message: string) => void
  ): Promise<{
    success: boolean;
    filename: string;
    fileId: string;
    sizeBytes: number;
    folderName: string;
    source: 'firebase' | 'mongodb';
    totalRecords: number;
    counts: Record<string, number>;
    webViewLink?: string;
  }> {
    const source = sourceOverride || this.config.backupSource || 'firebase';

    // Step 1: Preparing
    onProgress?.('preparing', `Preparing ${source === 'firebase' ? 'Firebase' : 'MongoDB'} database export...`);

    const accessToken = await this.ensureValidAccessToken(false);

    // Step 2: Creating backup file
    onProgress?.('creating_file', `Generating complete ${source === 'firebase' ? 'Firebase' : 'MongoDB'} backup payload...`);
    const { rawJson, filename, totalRecords, counts } = await this.generateBackupPayload(source);
    const sizeBytes = new Blob([rawJson]).size;

    // Step 3: Connecting to Google Drive & Verifying Folder
    onProgress?.('connecting', `Connecting to Google Drive and locating backup folder "${this.config.folderName || DEFAULT_FOLDER_NAME}"...`);
    const folder = await this.getOrCreateFolder(this.config.folderName || DEFAULT_FOLDER_NAME);

    // Step 4: Uploading backup
    onProgress?.('uploading', `Uploading "${filename}" (${(sizeBytes / 1024).toFixed(1)} KB) to Google Drive...`);

    const metadata = {
      name: filename,
      parents: [folder.id],
      description: `ARCO GST Billing System Full Database Backup (${source.toUpperCase()}) - ${totalRecords} records`,
      properties: {
        app: 'ARCO_GST_BILLING',
        sourceDatabase: source,
        recordCount: String(totalRecords),
        exportedAt: new Date().toISOString(),
      },
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: application/json\r\n\r\n' +
      rawJson +
      closeDelimiter;

    const uploadRes = await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,webViewLink,createdTime',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': `multipart/related; boundary=${boundary}`,
        },
        body: multipartRequestBody,
      }
    );

    if (!uploadRes.ok) {
      if (uploadRes.status === 401) {
        this.cachedAccessToken = null;
        this.notify();
        throw new Error('Google Drive authorization session expired during upload. Please reconnect and retry.');
      }
      const errJson = await uploadRes.json().catch(() => ({}));
      throw new Error(errJson.error?.message || `Failed to upload backup to Google Drive (HTTP ${uploadRes.status}).`);
    }

    const uploadData = await uploadRes.json();

    // Step 5: Completed successfully
    onProgress?.('completed', `Backup completed successfully! Uploaded "${filename}" to Google Drive.`);

    const nowIso = new Date().toISOString();
    this.saveConfig({
      lastBackupAt: nowIso,
      lastBackupFilename: filename,
      lastBackupSource: source,
      lastBackupStatus: 'SUCCESS',
      lastBackupSize: sizeBytes,
      lastBackupFileId: uploadData.id,
      lastBackupWebViewLink: uploadData.webViewLink,
    });

    auditService.log({
      action: 'EXPORT',
      entityType: 'BACKUP',
      entityId: uploadData.id || filename,
      entityName: `Google Drive Backup (${source})`,
      summary: `Uploaded complete ${source} database backup (${filename}, ${(sizeBytes / 1024).toFixed(1)} KB, ${totalRecords} records) to Google Drive folder "${folder.name}".`,
      details: {
        fileId: uploadData.id,
        filename,
        source,
        totalRecords,
        counts,
        folderName: folder.name,
      },
    });

    return {
      success: true,
      filename,
      fileId: uploadData.id,
      sizeBytes,
      folderName: folder.name,
      source,
      totalRecords,
      counts,
      webViewLink: uploadData.webViewLink,
    };
  }
}

export const googleDriveService = new GoogleDriveService();
