/**
 * Reliable, high-precision print helper service for web and thermal POS printing.
 * Eliminates print layout inconsistencies, blank first-attempts, and preview disparities
 * by extracting inlined styles, establishing proper paper viewports, and ensuring all
 * stylesheets, web fonts, and images (store logos, UPI QR codes) are 100% rendered
 * before invoking the browser print dialog.
 */

export interface PrintOptions {
  elementId?: string;
  element?: HTMLElement | null;
  format?: 'A4' | 'Thermal80' | 'Thermal70';
  customCss?: string;
  title?: string;
  onBeforePrint?: () => void;
  onAfterPrint?: () => void;
}

/**
 * Extract all CSS rules from parent document stylesheets and style elements
 * to guarantee instant, synchronous styling inside the print iframe without network lag.
 */
function extractAllDocumentStyles(): string {
  let combinedCss = '';

  // 1. Extract rules from accessible document.styleSheets
  try {
    for (let i = 0; i < document.styleSheets.length; i++) {
      const sheet = document.styleSheets[i];
      try {
        if (sheet.cssRules) {
          for (let j = 0; j < sheet.cssRules.length; j++) {
            combinedCss += sheet.cssRules[j].cssText + '\n';
          }
        }
      } catch {
        // Cross-origin stylesheet access restriction; fallback to @import rule
        if (sheet.href) {
          combinedCss += `@import url("${sheet.href}");\n`;
        }
      }
    }
  } catch (e) {
    console.warn('[PrintService] Note: Direct styleSheet extraction partial fallback:', e);
  }

  // 2. Also collect all inline <style> tag contents
  try {
    const inlineStyles = Array.from(document.querySelectorAll('style'))
      .map((s) => s.textContent || s.innerHTML || '')
      .join('\n');
    combinedCss = inlineStyles + '\n' + combinedCss;
  } catch (e) {
    console.warn('[PrintService] Note: Inline style extraction warning:', e);
  }

  return combinedCss;
}

export async function printElement(options: PrintOptions): Promise<void> {
  const { elementId, element: providedElement, format = 'A4', customCss = '', title = 'Print Document' } = options;
  const targetEl = providedElement || (elementId ? document.getElementById(elementId) : null);

  if (!targetEl) {
    console.warn('[PrintService] Printable element not found, falling back to standard window.print()');
    window.print();
    return;
  }

  // Remove any stale print frame
  const iframeId = 'arco-app-print-frame';
  const existingFrame = document.getElementById(iframeId);
  if (existingFrame) {
    existingFrame.remove();
  }

  // Determine realistic paper viewport dimensions based on format
  // (Prevents browser from computing layout on a 0px x 0px viewport which mangles first-attempt previews)
  let viewportWidth = '794px'; // A4 width at 96 DPI
  let viewportHeight = '1123px'; // A4 height at 96 DPI

  if (format === 'Thermal70') {
    viewportWidth = '265px'; // ~70mm at 96 DPI
    viewportHeight = '950px';
  } else if (format === 'Thermal80') {
    viewportWidth = '302px'; // ~80mm at 96 DPI
    viewportHeight = '950px';
  }

  // Create clean off-screen iframe with realistic paper dimensions
  const iframe = document.createElement('iframe');
  iframe.id = iframeId;
  iframe.style.position = 'fixed';
  iframe.style.top = '-99999px';
  iframe.style.left = '-99999px';
  iframe.style.width = viewportWidth;
  iframe.style.height = viewportHeight;
  iframe.style.border = 'none';
  iframe.style.visibility = 'hidden';
  iframe.style.pointerEvents = 'none';
  iframe.style.zIndex = '-9999';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) {
    window.print();
    return;
  }

  // Extract all stylesheets and external links from parent document
  const extractedStyles = extractAllDocumentStyles();
  const externalHeadLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"], link[rel="preconnect"]'))
    .map((el) => el.outerHTML)
    .join('\n');

  // Format specific layout CSS
  let formatPageCss = '';
  if (format === 'Thermal70') {
    formatPageCss = `
      @page { size: 70mm auto; margin: 1mm 0mm 0mm 0mm; }
      html, body {
        width: 70mm !important;
        max-width: 70mm !important;
        margin: 0 !important;
        margin-top: 1mm !important;
        margin-right: 0mm !important;
        padding: 1mm 0 0 0 !important;
        overflow-x: hidden !important;
        text-align: left !important;
        font-family: monospace, 'Courier New', Courier, monospace !important;
        font-weight: 700 !important;
        font-size: 11px !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
      }
      * {
        box-sizing: border-box !important;
      }
      .print-container,
      .thermal-70mm-slip,
      #thermal-70mm-print-slip,
      #thermal-70mm-register-slip,
      #thermal-70mm-ledger-slip {
        width: 70mm !important;
        max-width: 70mm !important;
        margin: 0 !important;
        margin-top: 1mm !important;
        margin-right: 0mm !important;
        padding-top: 1mm !important;
        padding-right: 0mm !important;
        padding-bottom: 0 !important;
        padding-left: 0 !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
        border: none !important;
        box-shadow: none !important;
        background-color: #ffffff !important;
        color: #000000 !important;
      }
      .thermal-70mm-slip,
      .thermal-70mm-slip * {
        background-color: #ffffff !important;
        color: #000000 !important;
        font-weight: 700 !important;
      }
      div, table, tr, td, th, p, span {
        box-sizing: border-box !important;
        max-width: 100% !important;
      }
      table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        margin: 4px 0 !important;
      }
      td, th {
        box-sizing: border-box !important;
        overflow-wrap: break-word !important;
        word-break: break-word !important;
      }
    `;
  } else if (format === 'Thermal80') {
    formatPageCss = `
      @page { size: 80mm auto; margin: 1mm 0mm 0mm 0mm; }
      html, body {
        width: 80mm !important;
        max-width: 80mm !important;
        margin: 0 !important;
        margin-top: 1mm !important;
        margin-right: 0mm !important;
        padding: 1mm 0 0 0 !important;
        overflow-x: hidden !important;
        text-align: left !important;
        font-family: monospace, 'Courier New', Courier, monospace !important;
        font-weight: 700 !important;
        font-size: 12px !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
      }
      * {
        box-sizing: border-box !important;
      }
      .print-container,
      .thermal-80mm-slip,
      #thermal-80mm-print-slip,
      #thermal-80mm-register-slip,
      #thermal-80mm-ledger-slip {
        width: 80mm !important;
        max-width: 80mm !important;
        margin: 0 !important;
        margin-top: 1mm !important;
        margin-right: 0mm !important;
        padding-top: 1mm !important;
        padding-right: 0mm !important;
        padding-bottom: 0 !important;
        padding-left: 0 !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
        border: none !important;
        box-shadow: none !important;
        background-color: #ffffff !important;
        color: #000000 !important;
      }
      .thermal-80mm-slip,
      .thermal-80mm-slip * {
        background-color: #ffffff !important;
        color: #000000 !important;
        font-weight: 700 !important;
      }
      div, table, tr, td, th, p, span {
        box-sizing: border-box !important;
        max-width: 100% !important;
      }
      table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        margin: 4px 0 !important;
      }
      td, th {
        box-sizing: border-box !important;
        overflow-wrap: break-word !important;
        word-break: break-word !important;
      }
    `;
  } else {
    formatPageCss = `
      @page { size: A4 portrait; margin: 6mm; }
      html, body {
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
      }
      * {
        box-sizing: border-box !important;
      }
    `;
  }

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>${title}</title>
        ${externalHeadLinks}
        <style>
          ${extractedStyles}
          ${formatPageCss}
          ${customCss}
          body {
            background: #ffffff !important;
            color: #000000 !important;
            visibility: visible !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            color-adjust: exact !important;
          }
          .no-print, .print\\:hidden, #btn-trigger-print, #btn-close-print-modal {
            display: none !important;
            visibility: hidden !important;
          }
          img {
            max-width: 100% !important;
            height: auto !important;
            image-rendering: -webkit-optimize-contrast;
            image-rendering: crisp-edges;
          }
        </style>
      </head>
      <body>
        ${targetEl.innerHTML}
      </body>
    </html>
  `;

  doc.open();
  doc.write(htmlContent);
  doc.close();

  // 1. Wait for document ready & images decoding
  const waitForImages = new Promise<void>((resolve) => {
    const images = Array.from(doc.images);
    if (images.length === 0) {
      resolve();
      return;
    }

    let remaining = images.length;
    const onDone = () => {
      remaining--;
      if (remaining <= 0) resolve();
    };

    images.forEach((img) => {
      if (img.complete && img.naturalWidth > 0) {
        onDone();
      } else {
        if (typeof img.decode === 'function') {
          img.decode().then(onDone).catch(onDone);
        } else {
          img.onload = onDone;
          img.onerror = onDone;
        }
      }
    });
  });

  // 2. Wait for fonts loaded in both iframe and parent document
  const waitForFonts = new Promise<void>((resolve) => {
    const parentFontsReady = (document as any).fonts?.ready || Promise.resolve();
    const iframeFontsReady = (doc as any).fonts?.ready || Promise.resolve();

    Promise.all([parentFontsReady, iframeFontsReady])
      .then(() => resolve())
      .catch(() => resolve());
  });

  // 3. Safety timeout guard (max 450ms)
  const timeoutGuard = new Promise<void>((resolve) => {
    setTimeout(resolve, 450);
  });

  await Promise.race([Promise.all([waitForImages, waitForFonts]), timeoutGuard]);

  // 4. Force synchronous browser layout reflow (Layout Thrash to guarantee paint tree validity)
  try {
    const _body = doc.body;
    if (_body) {
      void _body.offsetHeight;
      void _body.getBoundingClientRect();
    }
  } catch {
    // Ignore layout read error
  }

  // 5. Wait for 2 requestAnimationFrames to let the compositor finalize styling
  await new Promise((resolve) => {
    requestAnimationFrame(() => {
      requestAnimationFrame(resolve);
    });
  });

  options.onBeforePrint?.();

  try {
    iframe.contentWindow?.focus();
    iframe.contentWindow?.print();
  } catch (err) {
    console.error('[PrintService] Iframe print failed, falling back to window.print():', err);
    window.print();
  }

  // Auto clean up after printing completes
  const cleanup = () => {
    try {
      if (document.getElementById(iframeId)) {
        iframe.remove();
      }
    } catch {
      // Ignore cleanup error
    }
  };

  if (iframe.contentWindow) {
    iframe.contentWindow.addEventListener('afterprint', cleanup, { once: true });
  }
  // Fallback cleanup timer in case afterprint does not fire
  setTimeout(cleanup, 10000);

  options.onAfterPrint?.();
}

