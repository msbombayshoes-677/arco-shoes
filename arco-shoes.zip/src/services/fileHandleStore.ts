/**
 * Persistent store for File System Access API Directory Handles using IndexedDB.
 * Allows the application to save auto-backups directly into the user's selected active folder on their computer.
 */

const DB_NAME = 'arco_erp_fs_store';
const STORE_NAME = 'dir_handles';
const KEY = 'active_backup_directory';

let inMemoryDirHandle: any = null;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB is not supported in this environment.'));
    }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveDirectoryHandle(handle: any): Promise<void> {
  inMemoryDirHandle = handle;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(handle, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[Directory Handle Store] IndexedDB persistence warning:', err);
  }
}

export async function getSavedDirectoryHandle(): Promise<any | null> {
  if (inMemoryDirHandle) {
    return inMemoryDirHandle;
  }
  try {
    const db = await openDb();
    const handle = await new Promise<any>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(KEY);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    if (handle) {
      inMemoryDirHandle = handle;
      return handle;
    }
  } catch (err) {
    console.warn('[Directory Handle Store] Could not read from IndexedDB:', err);
  }
  return null;
}

export async function clearSavedDirectoryHandle(): Promise<void> {
  inMemoryDirHandle = null;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[Directory Handle Store] Clear warning:', err);
  }
}

/**
 * Attempts to write backup content directly to the provided directory handle.
 * Returns true if successful, false otherwise.
 */
export async function writeBackupToFileSystemHandle(
  handle: any,
  filename: string,
  content: string
): Promise<boolean> {
  if (!handle || typeof handle.getFileHandle !== 'function') {
    return false;
  }
  try {
    // Check permission if queryPermission is available
    if (typeof handle.queryPermission === 'function') {
      const perm = await handle.queryPermission({ mode: 'readwrite' });
      if (perm !== 'granted') {
        if (typeof handle.requestPermission === 'function') {
          const reqPerm = await handle.requestPermission({ mode: 'readwrite' });
          if (reqPerm !== 'granted') return false;
        } else {
          return false;
        }
      }
    }

    const fileHandle = await handle.getFileHandle(filename, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
    return true;
  } catch (err) {
    console.warn('[Directory Handle Store] File write failed:', err);
    return false;
  }
}
