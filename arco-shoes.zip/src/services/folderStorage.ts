/**
 * IndexedDB helper for persisting and retrieving the FileSystemDirectoryHandle
 * for the user's active backup path.
 */

const DB_NAME = 'arco_filesystem_db';
const STORE_NAME = 'handles';
const KEY_NAME = 'active_backup_folder_handle';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB not supported in this environment'));
    }
    const req = window.indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function storeDirectoryHandle(handle: FileSystemDirectoryHandle): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put(handle, KEY_NAME);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[storeDirectoryHandle Notice]:', err);
  }
}

export async function getStoredDirectoryHandle(): Promise<FileSystemDirectoryHandle | null> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const req = store.get(KEY_NAME);
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[getStoredDirectoryHandle Notice]:', err);
    return null;
  }
}

export async function clearStoredDirectoryHandle(): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).delete(KEY_NAME);
  } catch (err) {
    console.warn('[clearStoredDirectoryHandle Notice]:', err);
  }
}

export async function writeBackupToDirectoryHandle(
  dirHandle: FileSystemDirectoryHandle,
  filename: string,
  content: string
): Promise<boolean> {
  try {
    if (typeof (dirHandle as any).queryPermission === 'function') {
      const permission = await (dirHandle as any).queryPermission({ mode: 'readwrite' });
      if (permission !== 'granted') {
        if (typeof (dirHandle as any).requestPermission === 'function') {
          const req = await (dirHandle as any).requestPermission({ mode: 'readwrite' });
          if (req !== 'granted') return false;
        } else {
          return false;
        }
      }
    }
    const fileHandle = await dirHandle.getFileHandle(filename, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content);
    await writable.close();
    return true;
  } catch (err) {
    console.warn('[writeBackupToDirectoryHandle Notice]:', err);
    return false;
  }
}
