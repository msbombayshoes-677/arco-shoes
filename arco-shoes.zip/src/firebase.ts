// Import the functions you need from the SDKs you need
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";
import {
  initializeFirestore,
  getFirestore,
  Firestore,
  doc,
  setDoc,
  deleteDoc,
  getDocFromServer,
} from "firebase/firestore";
import { getAuth } from "firebase/auth";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyDJEaAX71Jw3PKzVOmlAV5_RQlQLzeV2Ic",
  authDomain: "arcoanantnag.firebaseapp.com",
  projectId: "arcoanantnag",
  storageBucket: "arcoanantnag.firebasestorage.app",
  messagingSenderId: "1081338356980",
  appId: "1:1081338356980:web:fd7cd80301e6060079aaa1",
};

export const FIRESTORE_DATABASE_ID = "ai-studio-arcoshoes-63292063-d63f-44d8-86c7-7338276c69be";

// Initialize Firebase
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Analytics safely initialized in browser context if measurementId is present
export let analytics: ReturnType<typeof getAnalytics> | null = null;
if (typeof window !== "undefined") {
  isSupported().then((supported) => {
    if (supported) {
      try {
        analytics = getAnalytics(app);
      } catch (err) {
        console.warn("Firebase Analytics initialization warning:", err);
      }
    }
  }).catch(() => {});
}

// Connect database id to 'ai-studio-arcoshoes-63292063-d63f-44d8-86c7-7338276c69be'
export const db: Firestore = (() => {
  try {
    return initializeFirestore(
      app,
      {
        experimentalAutoDetectLongPolling: true,
      },
      FIRESTORE_DATABASE_ID
    );
  } catch {
    return getFirestore(app, FIRESTORE_DATABASE_ID);
  }
})();

// Authoritative default database
export const defaultDb: Firestore | null = db;

// Validate Connection to Firestore on startup as mandated by Firebase Skill
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error: any) {
    if (
      error?.code === 'unavailable' ||
      (error instanceof Error &&
        (error.message.includes('the client is offline') || error.message.includes('offline')))
    ) {
      console.info("Firestore operating with local persistence / offline cache.");
    }
  }
}
testConnection();

export const auth = getAuth(app);

// Backend Details metadata for display in Settings & Diagnostics
export const BACKEND_DETAILS = {
  projectId: firebaseConfig.projectId,
  appId: firebaseConfig.appId,
  firestoreDatabaseId: FIRESTORE_DATABASE_ID,
  storageBucket: firebaseConfig.storageBucket,
  authDomain: firebaseConfig.authDomain,
  messagingSenderId: firebaseConfig.messagingSenderId,
  consoleDirectUrl: `https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore/databases/${FIRESTORE_DATABASE_ID}/data`,
  consoleDefaultUrl: `https://console.firebase.google.com/project/${firebaseConfig.projectId}/firestore`,
};

/**
 * Dual-sync write: Writes to primary Firestore database
 */
export async function syncDocToFirestore(collectionName: string, docId: string, data: any): Promise<void> {
  await setDoc(doc(db, collectionName, docId), data, { merge: true });
}

/**
 * Dual-sync delete: Deletes from primary Firestore database
 */
export async function syncDeleteFromFirestore(collectionName: string, docId: string): Promise<void> {
  await deleteDoc(doc(db, collectionName, docId));
}
