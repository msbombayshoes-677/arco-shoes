import React, { useMemo, useState } from 'react';
import {
  Building2,
  CreditCard,
  AlertCircle,
  ShoppingCart,
  Receipt,
  ArrowUpRight,
  Package,
  CheckCircle2,
  Calendar,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Supplier, PurchaseInvoice, SupplierPayment } from '../types';

interface SupplierDashboardProps {
  suppliers: Supplier[];
  purchases: PurchaseInvoice[];
  payments: SupplierPayment[];
  onNavigateToTab: (tab: any) => void;
}

export const SupplierDashboard: React.FC<SupplierDashboardProps> = ({
  suppliers,
  purchases,
  payments,
  onNavigateToTab,
}) => {
  // Filter limit states for 5, 10, 20
  const [payablesLimit, setPayablesLimit] = useState<number>(5);
  const [purchaseLimit, setPurchaseLimit] = useState<number>(5);

  // Current Month String (YYYY-MM)
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });

  const [selectedYearNum, selectedMonthNum] = useMemo(() => {
    const parts = selectedMonth.split('-');
    const y = parseInt(parts[0], 10) || new Date().getFullYear();
    const m = parseInt(parts[1], 10) || (new Date().getMonth() + 1);
    return [y, m];
  }, [selectedMonth]);

  const formattedMonthName = useMemo(() => {
    const d = new Date(selectedYearNum, selectedMonthNum - 1, 1);
    return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  }, [selectedYearNum, selectedMonthNum]);

  const handlePrevMonth = () => {
    let prevM = selectedMonthNum - 1;
    let prevY = selectedYearNum;
    if (prevM < 1) {
      prevM = 12;
      prevY -= 1;
    }
    setSelectedMonth(`${prevY}-${String(prevM).padStart(2, '0')}`);
  };

  const handleNextMonth = () => {
    let nextM = selectedMonthNum + 1;
    let nextY = selectedYearNum;
    if (nextM > 12) {
      nextM = 1;
      nextY += 1;
    }
    setSelectedMonth(`${nextY}-${String(nextM).padStart(2, '0')}`);
  };

  const handleCurrentMonth = () => {
    const d = new Date();
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  };

  // 1. TOP SUMMARY CARDS METRICS
  const totalActiveSuppliers = useMemo(() => {
    return suppliers.filter((s) => s.isActive !== false).length;
  }, [suppliers]);

  const totalAmountPaid = useMemo(() => {
    return payments.reduce((sum, p) => sum + (p.amountPaid || 0), 0);
  }, [payments]);

  const totalOutstandingPayable = useMemo(() => {
    return suppliers.reduce((sum, s) => sum + (s.currentBalance > 0 ? s.currentBalance : 0), 0);
  }, [suppliers]);

  const thisMonthPurchases = useMemo(() => {
    return purchases
      .filter((p) => p.purchaseDate && p.purchaseDate.startsWith(selectedMonth))
      .reduce((sum, p) => sum + (p.grandTotal || 0), 0);
  }, [purchases, selectedMonth]);

  const thisMonthPayments = useMemo(() => {
    return payments
      .filter((p) => p.voucherDate && p.voucherDate.startsWith(selectedMonth))
      .reduce((sum, p) => sum + (p.amountPaid || 0), 0);
  }, [payments, selectedMonth]);

  // 2. SUPPLIER METRICS AGGREGATION
  const allSuppliersPerformance = useMemo(() => {
    return suppliers.map((sup) => {
      const supPurchases = purchases.filter(
        (p) => p.supplierId === sup.id || (p.supplierName && p.supplierName.trim().toLowerCase() === sup.supplierName.trim().toLowerCase())
      );
      const supPayments = payments.filter(
        (p) => p.supplierId === sup.id || (p.supplierName && p.supplierName.trim().toLowerCase() === sup.supplierName.trim().toLowerCase())
      );

      const totalPurchase = supPurchases.reduce((sum, p) => sum + (p.grandTotal || 0), 0);
      const invoiceCount = supPurchases.length;
      const averageInvoiceValue = invoiceCount > 0 ? totalPurchase / invoiceCount : 0;
      const totalPaid = supPayments.reduce((sum, p) => sum + (p.amountPaid || 0), 0);
      const outstandingAmount = sup.currentBalance > 0 ? sup.currentBalance : 0;

      return {
        id: sup.id,
        supplierCode: sup.supplierCode || sup.id,
        supplierName: sup.supplierName,
        mobile: sup.mobile,
        city: sup.city || 'N/A',
        totalPurchase,
        invoiceCount,
        averageInvoiceValue,
        totalPaid,
        outstandingAmount,
      };
    });
  }, [suppliers, purchases, payments]);

  // Top Suppliers by Payables / Outstanding
  const filteredPayables = useMemo(() => {
    return [...allSuppliersPerformance]
      .filter((s) => s.outstandingAmount > 0)
      .sort((a, b) => b.outstandingAmount - a.outstandingAmount)
      .slice(0, payablesLimit);
  }, [allSuppliersPerformance, payablesLimit]);

  // Top Suppliers by Purchase Value
  const filteredByPurchase = useMemo(() => {
    const totalAllPurchases = purchases.reduce((sum, p) => sum + (p.grandTotal || 0), 0) || 1;
    return [...allSuppliersPerformance]
      .filter((s) => s.totalPurchase > 0)
      .sort((a, b) => b.totalPurchase - a.totalPurchase)
      .slice(0, purchaseLimit)
      .map((s) => ({
        ...s,
        purchaseShare: (s.totalPurchase / totalAllPurchases) * 100,
      }));
  }, [allSuppliersPerformance, purchases, purchaseLimit]);

  return (
    <div className="space-y-6">
      {/* 1. TOP SUMMARY CARDS (4 Cards) */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-slate-100">Supplier Overview</h2>
        <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs shadow-inner">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Calendar className="w-3.5 h-3.5 text-blue-400" />
            <span>Month:</span>
          </span>
          <button onClick={handlePrevMonth} title="Previous Month" className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"><ChevronLeft className="w-3.5 h-3.5" /></button>
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => e.target.value && setSelectedMonth(e.target.value)}
            className="bg-transparent text-slate-200 font-mono font-bold text-xs py-0.5 px-1 border border-slate-700/50 rounded focus:outline-none focus:border-blue-500 cursor-pointer"
          />
          <button onClick={handleNextMonth} title="Next Month" className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"><ChevronRight className="w-3.5 h-3.5" /></button>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Total Suppliers */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Suppliers</span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-100 font-sans tracking-tight">
              {totalActiveSuppliers}
            </div>
            <div className="text-[10.5px] text-purple-400 font-semibold mt-1">
              {suppliers.length} Total on record
            </div>
          </div>
        </div>

        {/* Card 2: This Month Payment */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">This Month Payment</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-amber-400 font-sans tracking-tight truncate">
              ₹{thisMonthPayments.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-amber-300 font-semibold mt-1">
              Paid in {formattedMonthName}
            </div>
          </div>
        </div>

        {/* Card 3: Amount Paid */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Amount Paid</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-100 font-sans tracking-tight truncate">
              ₹{totalAmountPaid.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-emerald-400 font-semibold mt-1">
              {payments.length} Payments Disbursed
            </div>
          </div>
        </div>

        {/* Card 4: Outstanding Payable */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Outstanding Payable</span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-rose-400 font-sans tracking-tight truncate">
              ₹{totalOutstandingPayable.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-rose-300/80 font-semibold mt-1">
              Total Balance Payable
            </div>
          </div>
        </div>
      </div>

      {/* 2 & 3. TWO-COLUMN ANALYTICS: Payables vs Purchase Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* SECTION 2: Top Suppliers by Outstanding Payables */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/60 transition-all shadow-md lg:col-span-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/70 mb-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400" />
                <h3 className="font-bold text-sm text-slate-100">Supplier Payables / Outstanding</h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400 font-semibold hidden sm:inline">Show:</span>
                <div className="flex items-center bg-slate-950/80 rounded-lg p-0.5 border border-slate-800">
                  {[5, 10, 20].map((limit) => (
                    <button
                      key={limit}
                      type="button"
                      onClick={() => setPayablesLimit(limit)}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded transition-all cursor-pointer ${
                        payablesLimit === limit
                          ? 'bg-rose-500 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      {limit}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {filteredPayables.length === 0 ? (
              <div className="p-8 text-center text-slate-400 space-y-1">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <p className="font-semibold text-slate-300 text-xs">No Pending Supplier Dues</p>
                <p className="text-[11px] text-slate-500">All supplier balances are completely settled!</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
                {filteredPayables.map((sup, idx) => (
                  <div
                    key={sup.id}
                    className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/70 hover:border-slate-700 transition space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                            #{idx + 1}
                          </span>
                          <span className="font-bold text-xs text-slate-100 truncate">{sup.supplierName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{sup.city}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-3 mt-1">
                          <span>Total Purchase: <strong className="text-slate-200">₹{sup.totalPurchase.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</strong></span>
                          <span>•</span>
                          <span>Total Paid: <strong className="text-emerald-400">₹{sup.totalPaid.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</strong></span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-xs font-black text-rose-400 font-mono">
                          ₹{sup.outstandingAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-rose-300/80 font-medium">Payable Due</div>
                      </div>
                    </div>

                    {/* Ratio Bar: Total Paid vs Payable Due */}
                    {(() => {
                      const paidVal = Math.max(0, sup.totalPaid || 0);
                      const dueVal = Math.max(0, sup.outstandingAmount || 0);
                      const totalCombined = paidVal + dueVal;

                      const paidRatio = totalCombined > 0 ? (paidVal / totalCombined) * 100 : (dueVal === 0 && paidVal > 0 ? 100 : 0);
                      const dueRatio = totalCombined > 0 ? 100 - paidRatio : (dueVal > 0 ? 100 : 0);

                      return (
                        <div className="space-y-1 pt-1">
                          <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden flex shadow-inner">
                            {paidRatio > 0 && (
                              <div
                                style={{ width: `${paidRatio}%` }}
                                className="bg-emerald-500 h-full transition-all duration-300"
                                title={`Total Paid: ₹${paidVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${paidRatio.toFixed(1)}%)`}
                              />
                            )}
                            {dueRatio > 0 && (
                              <div
                                style={{ width: `${dueRatio}%` }}
                                className="bg-rose-500 h-full transition-all duration-300"
                                title={`Payable Due: ₹${dueVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${dueRatio.toFixed(1)}%)`}
                              />
                            )}
                          </div>

                          <div className="flex items-center justify-between text-[10px] font-medium">
                            <span className="flex items-center gap-1.5 text-emerald-400">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                              <span>Paid: {paidRatio.toFixed(0)}%</span>
                              <span className="text-slate-500 font-mono">(₹{paidVal.toLocaleString('en-IN', { maximumFractionDigits: 0 })})</span>
                            </span>
                            <span className="flex items-center gap-1.5 text-rose-400">
                              <span className="text-slate-500 font-mono">(₹{dueVal.toLocaleString('en-IN', { maximumFractionDigits: 0 })})</span>
                              <span>Due: {dueRatio.toFixed(0)}%</span>
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 inline-block" />
                            </span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800/80 mt-3 flex items-center justify-between text-xs">
            <span className="text-[11px] text-slate-400">Manage vouchers in Payment Desk</span>
            <button
              type="button"
              onClick={() => onNavigateToTab('supplier_payment')}
              className="text-purple-400 hover:text-purple-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Make Supplier Payment</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* SECTION 3: Top Suppliers by Purchase Value */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/60 transition-all shadow-md lg:col-span-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/70 mb-3">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-blue-400" />
                <h3 className="font-bold text-sm text-slate-100">Supplier Purchase Analysis</h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400 font-semibold hidden sm:inline">Show:</span>
                <div className="flex items-center bg-slate-950/80 rounded-lg p-0.5 border border-slate-800">
                  {[5, 10, 20].map((limit) => (
                    <button
                      key={limit}
                      type="button"
                      onClick={() => setPurchaseLimit(limit)}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded transition-all cursor-pointer ${
                        purchaseLimit === limit
                          ? 'bg-blue-500 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      {limit}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {filteredByPurchase.length === 0 ? (
              <div className="p-8 text-center text-slate-400 space-y-1">
                <Package className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="font-semibold text-slate-300 text-xs">No Purchase Records Yet</p>
                <p className="text-[11px] text-slate-500">Inward supplier bills will appear here.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
                {filteredByPurchase.map((sup, idx) => (
                  <div
                    key={sup.id}
                    className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/70 hover:border-slate-700 transition space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                            #{idx + 1}
                          </span>
                          <span className="font-bold text-xs text-slate-100 truncate">{sup.supplierName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">({sup.invoiceCount} Bills)</span>
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-3 mt-1">
                          <span>Avg Bill: <strong className="text-slate-200">₹{sup.averageInvoiceValue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</strong></span>
                          <span>•</span>
                          <span>Share: <strong className="text-blue-400">{sup.purchaseShare.toFixed(1)}%</strong></span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-xs font-black text-blue-400 font-mono">
                          ₹{sup.totalPurchase.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-slate-400 font-medium">Net Purchase</div>
                      </div>
                    </div>

                    {/* Purchase Share Progress Bar */}
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${Math.min(100, Math.max(5, sup.purchaseShare))}%` }}
                        className="bg-gradient-to-r from-blue-500 to-indigo-500 h-full rounded-full"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800/80 mt-3 flex items-center justify-between text-xs">
            <span className="text-[11px] text-slate-400">View inward purchase register</span>
            <button
              type="button"
              onClick={() => onNavigateToTab('purchase_return')}
              className="text-blue-400 hover:text-blue-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Open Purchase Register</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
