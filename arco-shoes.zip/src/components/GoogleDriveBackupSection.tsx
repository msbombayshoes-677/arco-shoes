import React, { useState, useEffect } from 'react';
import {
  HardDrive,
  Cloud,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Folder,
  FolderPlus,
  ExternalLink,
  LogOut,
  LogIn,
  Database,
  ShieldCheck,
  Check,
  Layers,
  FileText,
  Sparkles,
  Server,
  Info,
  ChevronRight,
  ArrowRight,
  Clock,
} from 'lucide-react';
import {
  googleDriveService,
  GoogleDriveConfig,
  GoogleDriveUserInfo,
  GoogleDriveFile,
  BackupStep,
} from '../services/googleDriveService';
import { dbService } from '../services/storage';

export const GoogleDriveBackupSection: React.FC = () => {
  const [config, setConfig] = useState<GoogleDriveConfig>(() => googleDriveService.getConfig());
  const [isConnected, setIsConnected] = useState<boolean>(() => googleDriveService.isConnected());
  const [connectedUser, setConnectedUser] = useState<GoogleDriveUserInfo | null>(() =>
    googleDriveService.getConnectedUser()
  );
  const [backupFiles, setBackupFiles] = useState<GoogleDriveFile[]>([]);
  const [availableFolders, setAvailableFolders] = useState<Array<{ id: string; name: string }>>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupStep, setBackupStep] = useState<BackupStep>('idle');
  const [backupStepMsg, setBackupStepMsg] = useState<string>('');
  const [customFolderInput, setCustomFolderInput] = useState(config.folderName || 'ARCO_GST_Backups');
  const [showFolderCustomizer, setShowFolderCustomizer] = useState(false);

  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error' | 'info';
    title?: string;
    message: string;
  } | null>(null);

  const [lastBackupSummary, setLastBackupSummary] = useState<{
    filename: string;
    sizeBytes: number;
    folderName: string;
    source: 'firebase' | 'mongodb';
    totalRecords: number;
    counts: Record<string, number>;
    webViewLink?: string;
    timestamp: string;
  } | null>(null);

  const activeAppDb = dbService.getActiveDatabaseType();

  useEffect(() => {
    const unsubscribe = googleDriveService.subscribe(() => {
      const updatedConfig = googleDriveService.getConfig();
      setConfig(updatedConfig);
      setIsConnected(googleDriveService.isConnected());
      setConnectedUser(googleDriveService.getConnectedUser());
    });
    return () => unsubscribe();
  }, []);

  // Fetch recent files and folders if connected
  useEffect(() => {
    if (isConnected) {
      loadDriveData();
    }
  }, [isConnected, config.folderId]);

  const loadDriveData = async () => {
    try {
      const [files, folders] = await Promise.all([
        googleDriveService.listBackupFiles(),
        googleDriveService.listFolders(),
      ]);
      setBackupFiles(files);
      setAvailableFolders(folders);
    } catch (err) {
      console.warn('Error loading Drive file list:', err);
    }
  };

  const handleConnect = async () => {
    setIsConnecting(true);
    setFeedback(null);
    try {
      const { user } = await googleDriveService.connectGoogleDrive();
      setFeedback({
        type: 'success',
        title: 'Google Drive Connected',
        message: `Successfully connected Google Drive account (${user.email || 'Authenticated User'}). You can now backup your database.`,
      });
      loadDriveData();
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Connection Failed',
        message: err.message || 'Failed to authenticate with Google Drive.',
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    await googleDriveService.disconnectGoogleDrive();
    setBackupFiles([]);
    setFeedback({
      type: 'info',
      title: 'Google Drive Disconnected',
      message: 'Google Drive integration has been disconnected from this browser session.',
    });
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setFeedback(null);
    try {
      const res = await googleDriveService.testConnection();
      setFeedback({
        type: 'success',
        title: 'Connection Test Successful',
        message: res.message,
      });
      loadDriveData();
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Connection Test Failed',
        message: err.message || 'Unable to communicate with Google Drive API.',
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSourceChange = (newSource: 'firebase' | 'mongodb') => {
    googleDriveService.saveConfig({ backupSource: newSource });
    setFeedback({
      type: 'info',
      message: `Google Drive Backup Source Database set to: ${newSource === 'firebase' ? 'Firebase (Cloud Database)' : 'MongoDB (Local Database)'}`,
    });
    setTimeout(() => setFeedback(null), 3500);
  };

  const handleSaveCustomFolder = () => {
    const trimmed = customFolderInput.trim() || 'ARCO_GST_Backups';
    googleDriveService.saveConfig({ folderName: trimmed, folderId: undefined });
    setShowFolderCustomizer(false);
    setFeedback({
      type: 'success',
      message: `Target backup folder set to "${trimmed}". It will be verified/created in your Google Drive.`,
    });
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleSelectExistingFolder = (folder: { id: string; name: string }) => {
    setCustomFolderInput(folder.name);
    googleDriveService.saveConfig({ folderName: folder.name, folderId: folder.id });
    setShowFolderCustomizer(false);
    setFeedback({
      type: 'success',
      message: `Target backup folder updated to "${folder.name}".`,
    });
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleExecuteBackup = async () => {
    if (!isConnected) {
      setFeedback({
        type: 'error',
        title: 'Google Drive Not Connected',
        message: 'Please connect your Google Drive account before taking a backup.',
      });
      return;
    }

    setIsBackingUp(true);
    setBackupStep('preparing');
    setBackupStepMsg('Preparing backup...');
    setFeedback(null);
    setLastBackupSummary(null);

    try {
      const result = await googleDriveService.executeBackupToGoogleDrive(
        config.backupSource,
        (step, msg) => {
          setBackupStep(step);
          setBackupStepMsg(msg);
        }
      );

      setLastBackupSummary({
        filename: result.filename,
        sizeBytes: result.sizeBytes,
        folderName: result.folderName,
        source: result.source,
        totalRecords: result.totalRecords,
        counts: result.counts,
        webViewLink: result.webViewLink,
        timestamp: new Date().toISOString(),
      });

      setFeedback({
        type: 'success',
        title: 'Backup Upload Completed!',
        message: `Database successfully backed up to Google Drive folder "${result.folderName}". Uploaded ${result.filename} (${(result.sizeBytes / 1024).toFixed(1)} KB, ${result.totalRecords} total records).`,
      });

      loadDriveData();
    } catch (err: any) {
      setBackupStep('error');
      setFeedback({
        type: 'error',
        title: 'Backup to Google Drive Failed',
        message: err.message || 'An error occurred during database export or Google Drive upload.',
      });
    } finally {
      setIsBackingUp(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Feedback Banner */}
      {feedback && (
        <div
          className={`p-4 rounded-2xl border text-xs flex items-start gap-3 animate-in fade-in ${
            feedback.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : feedback.type === 'error'
              ? 'bg-rose-950/40 border-rose-500/40 text-rose-300'
              : 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          ) : feedback.type === 'error' ? (
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          ) : (
            <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          )}
          <div className="space-y-0.5">
            {feedback.title && <div className="font-bold text-sm text-white">{feedback.title}</div>}
            <div className="leading-relaxed">{feedback.message}</div>
          </div>
        </div>
      )}

      {/* Main 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Connection & Configuration */}
        <div className="lg:col-span-5 space-y-5">
          {/* 1. Google Drive Connection Card */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 shadow-xl text-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <HardDrive className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="font-bold text-sm text-white">Google Drive Connection</h2>
                  <p className="text-[11px] text-slate-400">OAuth 2.0 Secure Drive Storage</p>
                </div>
              </div>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1.5 ${
                  isConnected
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
                  }`}
                />
                {isConnected ? 'Connected' : 'Not Connected'}
              </span>
            </div>

            {/* Account Info display */}
            {isConnected && connectedUser ? (
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  {connectedUser.photoUrl ? (
                    <img
                      src={connectedUser.photoUrl}
                      alt={connectedUser.name}
                      className="w-8 h-8 rounded-full border border-slate-700 object-cover"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                      {connectedUser.email.charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white truncate">{connectedUser.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono truncate">{connectedUser.email}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={handleDisconnect}
                    className="p-1.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 text-[10px] font-semibold transition cursor-pointer flex items-center gap-1"
                    title="Disconnect Google Drive"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Disconnect</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3.5 bg-slate-950/50 border border-dashed border-slate-800 rounded-xl text-center space-y-2">
                <p className="text-xs text-slate-400">
                  Connect your Google account to store immutable database backups in your private Google Drive.
                </p>
                <button
                  onClick={handleConnect}
                  disabled={isConnecting}
                  className="w-full flex items-center justify-center gap-2.5 py-2 px-4 bg-white hover:bg-slate-100 text-slate-900 rounded-xl text-xs font-bold transition shadow cursor-pointer disabled:opacity-50"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>{isConnecting ? 'Connecting...' : 'Connect Google Drive'}</span>
                </button>
              </div>
            )}

            {/* Test Connection Button */}
            {isConnected && (
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-teal-400 hover:text-teal-300 border border-teal-500/30 rounded-xl text-xs font-bold transition cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                  <span>{isTesting ? 'Testing Drive Connection...' : 'Test Google Drive Connection'}</span>
                </button>

                <button
                  onClick={handleConnect}
                  disabled={isConnecting}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-xl text-xs font-medium transition cursor-pointer shrink-0"
                  title="Switch Google account"
                >
                  <span>Switch</span>
                </button>
              </div>
            )}
          </div>

          {/* 2. Backup Configuration Card */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 shadow-xl text-slate-100 space-y-4">
            <div className="flex items-center gap-2.5 border-b border-slate-800 pb-3">
              <div className="w-8 h-8 rounded-lg bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400">
                <Database className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-bold text-sm text-white">Backup Configuration</h2>
                <p className="text-[11px] text-slate-400">Source Database & Destination Folder</p>
              </div>
            </div>

            {/* Source Database Radio/Selector */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-300 block">
                Backup Source Database
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {/* Firebase Option */}
                <button
                  type="button"
                  onClick={() => handleSourceChange('firebase')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between cursor-pointer ${
                    config.backupSource === 'firebase'
                      ? 'bg-teal-950/50 border-teal-500/60 ring-1 ring-teal-500/40 text-white'
                      : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs flex items-center gap-1.5 text-white">
                      <Cloud className="w-3.5 h-3.5 text-amber-400" />
                      Firebase
                    </span>
                    {config.backupSource === 'firebase' && (
                      <span className="w-4 h-4 rounded-full bg-teal-500 text-slate-950 flex items-center justify-center text-[10px] font-bold">
                        ✓
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400">Cloud Firestore DB</span>
                  {activeAppDb === 'firebase' && (
                    <span className="mt-1 text-[9px] font-bold text-teal-400">● Active In App</span>
                  )}
                </button>

                {/* MongoDB Option */}
                <button
                  type="button"
                  onClick={() => handleSourceChange('mongodb')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between cursor-pointer ${
                    config.backupSource === 'mongodb'
                      ? 'bg-teal-950/50 border-teal-500/60 ring-1 ring-teal-500/40 text-white'
                      : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs flex items-center gap-1.5 text-white">
                      <Server className="w-3.5 h-3.5 text-emerald-400" />
                      MongoDB
                    </span>
                    {config.backupSource === 'mongodb' && (
                      <span className="w-4 h-4 rounded-full bg-teal-500 text-slate-950 flex items-center justify-center text-[10px] font-bold">
                        ✓
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400">Local Machine DB</span>
                  {activeAppDb === 'mongodb' && (
                    <span className="mt-1 text-[9px] font-bold text-emerald-400">● Active In App</span>
                  )}
                </button>
              </div>

              <p className="text-[10px] text-slate-400 leading-tight">
                Currently selected source:{' '}
                <strong className="text-teal-300">
                  {config.backupSource === 'firebase' ? 'Firebase' : 'MongoDB'}
                </strong>
                . When you click "Backup to Google Drive", the complete{' '}
                {config.backupSource === 'firebase' ? 'Firebase' : 'MongoDB'} database will be exported.
              </p>
            </div>

            {/* Target Folder Configuration */}
            <div className="space-y-2 pt-2 border-t border-slate-800/80">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-300">
                  Google Drive Backup Folder
                </label>
                <button
                  type="button"
                  onClick={() => setShowFolderCustomizer(!showFolderCustomizer)}
                  className="text-[10px] font-semibold text-teal-400 hover:text-teal-300 cursor-pointer"
                >
                  {showFolderCustomizer ? 'Cancel' : 'Change Folder'}
                </button>
              </div>

              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Folder className="w-4 h-4 text-amber-400 shrink-0" />
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white truncate">
                      {config.folderName || 'ARCO_GST_Backups'}
                    </div>
                    {config.folderId && (
                      <div className="text-[9px] text-slate-500 font-mono truncate">
                        ID: {config.folderId}
                      </div>
                    )}
                  </div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-teal-400 border border-slate-800 font-mono shrink-0">
                  Target
                </span>
              </div>

              {/* Folder Customizer dropdown / input */}
              {showFolderCustomizer && (
                <div className="p-3 bg-slate-950/90 border border-slate-700 rounded-xl space-y-3 animate-in fade-in">
                  <div className="space-y-1">
                    <label className="text-[10px] font-semibold text-slate-400">Folder Name</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={customFolderInput}
                        onChange={(e) => setCustomFolderInput(e.target.value)}
                        placeholder="e.g. ARCO_GST_Backups"
                        className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                      />
                      <button
                        type="button"
                        onClick={handleSaveCustomFolder}
                        className="px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-xs font-bold transition cursor-pointer"
                      >
                        Set
                      </button>
                    </div>
                  </div>

                  {availableFolders.length > 0 && (
                    <div className="space-y-1.5 pt-2 border-t border-slate-800">
                      <div className="text-[10px] font-semibold text-slate-400">Or Select Existing Drive Folder:</div>
                      <div className="max-h-28 overflow-y-auto space-y-1 pr-1">
                        {availableFolders.map((f) => (
                          <button
                            key={f.id}
                            type="button"
                            onClick={() => handleSelectExistingFolder(f)}
                            className="w-full flex items-center justify-between px-2.5 py-1 rounded-lg bg-slate-900/60 hover:bg-slate-800 text-[11px] text-slate-300 transition text-left cursor-pointer"
                          >
                            <span className="flex items-center gap-1.5 truncate">
                              <Folder className="w-3 h-3 text-amber-400 shrink-0" />
                              <span className="truncate">{f.name}</span>
                            </span>
                            <span className="text-[9px] text-teal-400 shrink-0">Select</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Backup Action & Results */}
        <div className="lg:col-span-7 space-y-5">
          {/* 1. Main "Backup to Google Drive" Action Card */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 shadow-xl text-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shadow-inner">
                  <Cloud className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-white">Execute Google Drive Backup</h2>
                  <p className="text-xs text-slate-400">
                    Export complete current database and upload to Google Drive
                  </p>
                </div>
              </div>
              <div className="px-3 py-1 rounded-full bg-slate-950/80 border border-slate-800 text-xs text-slate-300">
                Source:{' '}
                <strong className="text-teal-400">
                  {config.backupSource === 'firebase' ? 'Firebase' : 'MongoDB'}
                </strong>
              </div>
            </div>

            {/* Live Progress Stages when backing up */}
            {isBackingUp && (
              <div className="p-4 bg-slate-950/80 border border-teal-500/40 rounded-xl space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-teal-300 flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin text-teal-400" />
                    <span>Backup in Progress...</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 uppercase">{backupStep}</span>
                </div>

                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div
                    className="bg-teal-500 h-2 rounded-full transition-all duration-300"
                    style={{
                      width:
                        backupStep === 'preparing'
                          ? '20%'
                          : backupStep === 'creating_file'
                          ? '45%'
                          : backupStep === 'connecting'
                          ? '70%'
                          : backupStep === 'uploading'
                          ? '90%'
                          : backupStep === 'completed'
                          ? '100%'
                          : '10%',
                    }}
                  />
                </div>

                <div className="text-xs text-slate-300 font-mono">{backupStepMsg}</div>
              </div>
            )}

            {/* Big Prominent Action Button */}
            <button
              onClick={handleExecuteBackup}
              disabled={!isConnected || isBackingUp}
              className={`w-full py-4 px-6 rounded-2xl font-black text-sm tracking-wide transition shadow-xl flex items-center justify-center gap-3 cursor-pointer ${
                !isConnected
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-60'
                  : isBackingUp
                  ? 'bg-teal-700 text-teal-200 cursor-wait'
                  : 'bg-gradient-to-r from-teal-600 via-teal-500 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white shadow-teal-900/30'
              }`}
            >
              <HardDrive className={`w-5 h-5 ${isBackingUp ? 'animate-bounce' : ''}`} />
              <span>
                {isBackingUp
                  ? 'Uploading Backup to Google Drive...'
                  : `Backup ${config.backupSource === 'firebase' ? 'Firebase' : 'MongoDB'} to Google Drive`}
              </span>
            </button>

            {!isConnected && (
              <p className="text-[11px] text-amber-400/90 text-center flex items-center justify-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>Please connect your Google Drive account above to enable backups.</span>
              </p>
            )}

            {/* Last Backup Detail Summary Card */}
            {(lastBackupSummary || config.lastBackupAt) && (
              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-teal-400" />
                    <span>Last Google Drive Backup Summary</span>
                  </div>
                  <span className="text-[10px] font-mono text-teal-300">
                    {new Date(lastBackupSummary?.timestamp || config.lastBackupAt!).toLocaleString()}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Source DB</div>
                    <div className="font-bold text-white uppercase">
                      {lastBackupSummary?.source || config.lastBackupSource || 'FIREBASE'}
                    </div>
                  </div>

                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Folder</div>
                    <div className="font-bold text-teal-300 truncate">
                      {lastBackupSummary?.folderName || config.folderName || 'ARCO_GST_Backups'}
                    </div>
                  </div>

                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">File Size</div>
                    <div className="font-bold text-slate-200">
                      {lastBackupSummary
                        ? `${(lastBackupSummary.sizeBytes / 1024).toFixed(1)} KB`
                        : config.lastBackupSize
                        ? `${(config.lastBackupSize / 1024).toFixed(1)} KB`
                        : 'Recorded'}
                    </div>
                  </div>

                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">Status</div>
                    <div className="font-bold text-emerald-400 flex items-center gap-1">
                      <span>✓ Completed</span>
                    </div>
                  </div>
                </div>

                <div className="text-[11px] font-mono text-slate-300 bg-slate-900/90 p-2 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span className="truncate">
                    File: {lastBackupSummary?.filename || config.lastBackupFilename}
                  </span>
                  {(lastBackupSummary?.webViewLink || config.lastBackupWebViewLink) && (
                    <a
                      href={lastBackupSummary?.webViewLink || config.lastBackupWebViewLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-teal-400 hover:text-teal-300 font-sans text-xs flex items-center gap-1 shrink-0 ml-2"
                    >
                      <span>Open in Drive</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* 2. Recent Backups in Google Drive Card */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-5 shadow-xl text-slate-100 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Folder className="w-4 h-4 text-teal-400" />
                <h3 className="font-bold text-sm text-white">Backups in Google Drive Folder</h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-teal-400 border border-slate-700">
                  {backupFiles.length} File{backupFiles.length === 1 ? '' : 's'}
                </span>
                {isConnected && (
                  <button
                    onClick={loadDriveData}
                    className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    title="Refresh file list"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {!isConnected ? (
                <div className="py-8 text-center text-slate-500 text-xs">
                  Connect Google Drive to list files in the target folder.
                </div>
              ) : backupFiles.length === 0 ? (
                <div className="py-8 text-center text-slate-500 text-xs">
                  No backup files found yet in folder "{config.folderName}". Click "Backup to Google Drive" to create your first backup!
                </div>
              ) : (
                backupFiles.map((file) => (
                  <div
                    key={file.id}
                    className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <FileText className="w-4 h-4 text-teal-400 shrink-0" />
                      <div className="min-w-0">
                        <div className="font-bold text-white truncate">{file.name}</div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-2">
                          {file.createdTime && (
                            <span>{new Date(file.createdTime).toLocaleString()}</span>
                          )}
                          {file.size && (
                            <span>• {(Number(file.size) / 1024).toFixed(1)} KB</span>
                          )}
                        </div>
                      </div>
                    </div>

                    {file.webViewLink && (
                      <a
                        href={file.webViewLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-teal-400 rounded-lg text-[11px] font-bold transition flex items-center gap-1 shrink-0"
                      >
                        <span>View</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
