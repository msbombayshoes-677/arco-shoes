import React, { useMemo, useState } from 'react';
import {
  Users,
  CreditCard,
  AlertCircle,
  TrendingUp,
  Receipt,
  ArrowUpRight,
  Package,
  CheckCircle2,
  Building2,
  Tag,
  PhoneCall,
  Calendar,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { Customer, SalesInvoice, CustomerReceipt } from '../types';

interface CustomerDashboardProps {
  customers: Customer[];
  sales: SalesInvoice[];
  receipts: CustomerReceipt[];
  onNavigateToTab: (tab: any) => void;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  customers,
  sales,
  receipts,
  onNavigateToTab,
}) => {
  // Filter limit states for 5, 10, 20
  const [receivablesLimit, setReceivablesLimit] = useState<number>(5);
  const [salesLimit, setSalesLimit] = useState<number>(5);

  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });

  const [selectedYearNum, selectedMonthNum] = useMemo(() => {
    const parts = selectedMonth.split('-');
    const y = parseInt(parts[0], 10) || new Date().getFullYear();
    const m = parseInt(parts[1], 10) || (new Date().getMonth() + 1);
    return [y, m];
  }, [selectedMonth]);

  const formattedMonthName = useMemo(() => {
    const d = new Date(selectedYearNum, selectedMonthNum - 1, 1);
    return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  }, [selectedYearNum, selectedMonthNum]);

  const handlePrevMonth = () => {
    let prevM = selectedMonthNum - 1;
    let prevY = selectedYearNum;
    if (prevM < 1) {
      prevM = 12;
      prevY -= 1;
    }
    setSelectedMonth(`${prevY}-${String(prevM).padStart(2, '0')}`);
  };

  const handleNextMonth = () => {
    let nextM = selectedMonthNum + 1;
    let nextY = selectedYearNum;
    if (nextM > 12) {
      nextM = 1;
      nextY += 1;
    }
    setSelectedMonth(`${nextY}-${String(nextM).padStart(2, '0')}`);
  };

  const handleCurrentMonth = () => {
    const d = new Date();
    setSelectedMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  };

  // 1. TOP SUMMARY CARDS METRICS
  const totalActiveCustomers = useMemo(() => {
    return customers.filter((c) => c.isActive !== false).length;
  }, [customers]);

  // Registered Customer Sales only (excluding walk-in / counter sales)
  const registeredSales = useMemo(() => {
    const regCustIds = new Set(
      customers
        .filter((c) => c.id && c.id.trim() !== '' && c.id !== 'CUST-000')
        .map((c) => c.id.trim().toUpperCase())
    );
    const regCustCodes = new Set(
      customers
        .filter((c) => c.customerCode && c.customerCode.trim() !== '' && c.customerCode.trim().toUpperCase() !== 'CUST-000')
        .map((c) => c.customerCode.trim().toUpperCase())
    );
    const regCustNames = new Set(
      customers
        .map((c) => (c.customerName || '').trim().toLowerCase())
        .filter((name) => name !== '' && name !== 'na' && name !== 'counter sales' && name !== 'local counter sales')
    );

    return sales.filter((s) => {
      const sCustId = (s.customerId || '').trim().toUpperCase();
      const sCustName = (s.customerName || '').trim().toLowerCase();

      // Explicitly reject walk-in / anonymous counter sales
      if (sCustId === 'CUST-000' && (!sCustName || sCustName === 'na' || sCustName === 'local counter sales' || !regCustNames.has(sCustName))) {
        return false;
      }

      // Match by registered customer ID or Customer Code
      if (sCustId && sCustId !== 'CUST-000' && (regCustIds.has(sCustId) || regCustCodes.has(sCustId))) {
        return true;
      }

      // Match by registered customer name
      if (sCustName && regCustNames.has(sCustName)) {
        return true;
      }

      return false;
    });
  }, [customers, sales]);

  const monthlyRegisteredSales = useMemo(() => {
    return registeredSales.filter((s) => s.invoiceDate && s.invoiceDate.startsWith(selectedMonth));
  }, [registeredSales, selectedMonth]);

  const totalRegisteredCustomerSales = useMemo(() => {
    return monthlyRegisteredSales.reduce((sum, s) => sum + (s.grandTotal || 0), 0);
  }, [monthlyRegisteredSales]);

  const monthlyReceipts = useMemo(() => {
    return receipts.filter((r) => r.voucherDate && r.voucherDate.startsWith(selectedMonth));
  }, [receipts, selectedMonth]);

  const totalAmountReceived = useMemo(() => {
    return monthlyReceipts.reduce((sum, r) => sum + (r.amountReceived || 0), 0);
  }, [monthlyReceipts]);

  const totalOutstandingReceivable = useMemo(() => {
    return customers.reduce((sum, c) => sum + (c.currentBalance > 0 ? c.currentBalance : 0), 0);
  }, [customers]);

  // 2. CUSTOMER METRICS AGGREGATION
  const allCustomersPerformance = useMemo(() => {
    return customers.map((cust) => {
      const custSales = sales.filter(
        (s) =>
          s.customerId === cust.id ||
          (s.customerName && s.customerName.trim().toLowerCase() === cust.customerName.trim().toLowerCase())
      );
      const custReceipts = receipts.filter(
        (r) =>
          r.customerId === cust.id ||
          (r.customerName && r.customerName.trim().toLowerCase() === cust.customerName.trim().toLowerCase())
      );

      const totalSales = custSales.reduce((sum, s) => sum + (s.grandTotal || 0), 0);
      const invoiceCount = custSales.length;
      const averageInvoiceValue = invoiceCount > 0 ? totalSales / invoiceCount : 0;
      const totalReceived = custReceipts.reduce((sum, r) => sum + (r.amountReceived || 0), 0);
      const outstandingAmount = cust.currentBalance > 0 ? cust.currentBalance : 0;

      return {
        id: cust.id,
        customerCode: cust.customerCode || cust.id,
        customerName: cust.customerName,
        customerType: cust.customerType || 'Retail',
        mobile: cust.mobile,
        city: cust.city || 'N/A',
        totalSales,
        invoiceCount,
        averageInvoiceValue,
        totalReceived,
        outstandingAmount,
      };
    });
  }, [customers, sales, receipts]);

  // Top Customers by Receivables / Outstanding
  const filteredReceivables = useMemo(() => {
    return [...allCustomersPerformance]
      .filter((c) => c.outstandingAmount > 0)
      .sort((a, b) => b.outstandingAmount - a.outstandingAmount)
      .slice(0, receivablesLimit);
  }, [allCustomersPerformance, receivablesLimit]);

  // Top Customers by Sales Value
  const filteredBySales = useMemo(() => {
    const totalAllSales = totalRegisteredCustomerSales > 0 ? totalRegisteredCustomerSales : 1;
    return [...allCustomersPerformance]
      .filter((c) => c.totalSales > 0)
      .sort((a, b) => b.totalSales - a.totalSales)
      .slice(0, salesLimit)
      .map((c) => ({
        ...c,
        salesShare: (c.totalSales / totalAllSales) * 100,
      }));
  }, [allCustomersPerformance, totalRegisteredCustomerSales, salesLimit]);

  return (
    <div className="space-y-6">
      {/* 1. TOP SUMMARY CARDS (4 Cards) */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-slate-100">Customer Overview</h2>
        <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs shadow-inner">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Calendar className="w-3.5 h-3.5 text-blue-400" />
            <span>Month:</span>
          </span>
          <button onClick={handlePrevMonth} title="Previous Month" className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"><ChevronLeft className="w-3.5 h-3.5" /></button>
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => e.target.value && setSelectedMonth(e.target.value)}
            className="bg-transparent text-slate-200 font-mono font-bold text-xs py-0.5 px-1 border border-slate-700/50 rounded focus:outline-none focus:border-blue-500 cursor-pointer"
          />
          <button onClick={handleNextMonth} title="Next Month" className="p-1 text-slate-400 hover:text-slate-100 rounded hover:bg-slate-800 transition-colors cursor-pointer"><ChevronRight className="w-3.5 h-3.5" /></button>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Total Customers */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Customers</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-100 font-sans tracking-tight">
              {totalActiveCustomers}
            </div>
            <div className="text-[10.5px] text-cyan-400 font-semibold mt-1">
              {customers.length} Total on record
            </div>
          </div>
        </div>

        {/* Card 2: Customer Sales */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Customer Sales</span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-blue-400 font-sans tracking-tight truncate">
              ₹{totalRegisteredCustomerSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-blue-300/80 font-semibold mt-1">
              {registeredSales.length} {registeredSales.length === 1 ? 'Registered Invoice' : 'Registered Invoices'}
            </div>
          </div>
        </div>

        {/* Card 3: Amount Received */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Amount Received</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-100 font-sans tracking-tight truncate">
              ₹{totalAmountReceived.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-emerald-400 font-semibold mt-1">
              {receipts.length} Receipts Collected
            </div>
          </div>
        </div>

        {/* Card 4: Outstanding Receivable */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-4 sm:p-5 hover:border-slate-700/60 transition-all shadow-md flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Outstanding Receivable</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-amber-400 font-sans tracking-tight truncate">
              ₹{totalOutstandingReceivable.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[10.5px] text-amber-300/80 font-semibold mt-1">
              Total Balance Receivable
            </div>
          </div>
        </div>
      </div>

      {/* 2 & 3. TWO-COLUMN ANALYTICS: Receivables vs Sales Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* SECTION 2: Top Customers by Outstanding Receivables */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/60 transition-all shadow-md lg:col-span-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/70 mb-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                <h3 className="font-bold text-sm text-slate-100">Customer Receivables / Outstanding</h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400 font-semibold hidden sm:inline">Show:</span>
                <div className="flex items-center bg-slate-950/80 rounded-lg p-0.5 border border-slate-800">
                  {[5, 10, 20].map((limit) => (
                    <button
                      key={limit}
                      type="button"
                      onClick={() => setReceivablesLimit(limit)}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded transition-all cursor-pointer ${
                        receivablesLimit === limit
                          ? 'bg-amber-500 text-slate-950 font-black shadow-sm'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      {limit}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {filteredReceivables.length === 0 ? (
              <div className="p-8 text-center text-slate-400 space-y-1">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                <p className="font-semibold text-slate-300 text-xs">No Pending Customer Dues</p>
                <p className="text-[11px] text-slate-500">All customer balances are completely collected!</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
                {filteredReceivables.map((cust, idx) => (
                  <div
                    key={cust.id}
                    className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/70 hover:border-slate-700 transition space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                            #{idx + 1}
                          </span>
                          <span className="font-bold text-xs text-slate-100 truncate">{cust.customerName}</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono shrink-0">
                            {cust.customerType}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">{cust.city}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-3 mt-1">
                          <span>Total Sales: <strong className="text-slate-200">₹{cust.totalSales.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</strong></span>
                          <span>•</span>
                          <span>Total Received: <strong className="text-emerald-400">₹{cust.totalReceived.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</strong></span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-xs font-black text-amber-400 font-mono">
                          ₹{cust.outstandingAmount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-amber-300/80 font-medium">Receivable Due</div>
                      </div>
                    </div>

                    {/* Ratio Bar: Total Received vs Receivable Due */}
                    {(() => {
                      const receivedVal = Math.max(0, cust.totalReceived || 0);
                      const dueVal = Math.max(0, cust.outstandingAmount || 0);
                      const totalCombined = receivedVal + dueVal;

                      const receivedRatio = totalCombined > 0 ? (receivedVal / totalCombined) * 100 : (dueVal === 0 && receivedVal > 0 ? 100 : 0);
                      const dueRatio = totalCombined > 0 ? 100 - receivedRatio : (dueVal > 0 ? 100 : 0);

                      return (
                        <div className="space-y-1 pt-1">
                          <div className="w-full bg-slate-800/80 h-2 rounded-full overflow-hidden flex shadow-inner">
                            {receivedRatio > 0 && (
                              <div
                                style={{ width: `${receivedRatio}%` }}
                                className="bg-emerald-500 h-full transition-all duration-300"
                                title={`Total Received: ₹${receivedVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${receivedRatio.toFixed(1)}%)`}
                              />
                            )}
                            {dueRatio > 0 && (
                              <div
                                style={{ width: `${dueRatio}%` }}
                                className="bg-amber-500 h-full transition-all duration-300"
                                title={`Receivable Due: ₹${dueVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (${dueRatio.toFixed(1)}%)`}
                              />
                            )}
                          </div>

                          <div className="flex items-center justify-between text-[10px] font-medium">
                            <span className="flex items-center gap-1.5 text-emerald-400">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                              <span>Received: {receivedRatio.toFixed(0)}%</span>
                              <span className="text-slate-500 font-mono">(₹{receivedVal.toLocaleString('en-IN', { maximumFractionDigits: 0 })})</span>
                            </span>
                            <span className="flex items-center gap-1.5 text-amber-400">
                              <span className="text-slate-500 font-mono">(₹{dueVal.toLocaleString('en-IN', { maximumFractionDigits: 0 })})</span>
                              <span>Due: {dueRatio.toFixed(0)}%</span>
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 inline-block" />
                            </span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800/80 mt-3 flex items-center justify-between text-xs">
            <span className="text-[11px] text-slate-400">Manage receipts in Receipt Desk</span>
            <button
              type="button"
              onClick={() => onNavigateToTab('customer_receipt')}
              className="text-emerald-400 hover:text-emerald-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Receive Customer Payment</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* SECTION 3: Top Customers by Sales Value */}
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/60 transition-all shadow-md lg:col-span-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/70 mb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-cyan-400" />
                <h3 className="font-bold text-sm text-slate-100">Customer Sales Analysis</h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400 font-semibold hidden sm:inline">Show:</span>
                <div className="flex items-center bg-slate-950/80 rounded-lg p-0.5 border border-slate-800">
                  {[5, 10, 20].map((limit) => (
                    <button
                      key={limit}
                      type="button"
                      onClick={() => setSalesLimit(limit)}
                      className={`px-2 py-0.5 text-[10px] font-bold rounded transition-all cursor-pointer ${
                        salesLimit === limit
                          ? 'bg-cyan-500 text-slate-950 font-black shadow-sm'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      {limit}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {filteredBySales.length === 0 ? (
              <div className="p-8 text-center text-slate-400 space-y-1">
                <Package className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="font-semibold text-slate-300 text-xs">No Customer Sales Records Yet</p>
                <p className="text-[11px] text-slate-500">Outward customer invoices will appear here.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
                {filteredBySales.map((cust, idx) => (
                  <div
                    key={cust.id}
                    className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/70 hover:border-slate-700 transition space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                            #{idx + 1}
                          </span>
                          <span className="font-bold text-xs text-slate-100 truncate">{cust.customerName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">({cust.invoiceCount} Bills)</span>
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-3 mt-1">
                          <span>Avg Bill: <strong className="text-slate-200">₹{cust.averageInvoiceValue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</strong></span>
                          <span>•</span>
                          <span>Share: <strong className="text-cyan-400">{cust.salesShare.toFixed(1)}%</strong></span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-xs font-black text-cyan-400 font-mono">
                          ₹{cust.totalSales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className="text-[10px] text-slate-400 font-medium">Net Sales</div>
                      </div>
                    </div>

                    {/* Sales Share Progress Bar */}
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${Math.min(100, Math.max(5, cust.salesShare))}%` }}
                        className="bg-gradient-to-r from-cyan-500 to-teal-500 h-full rounded-full"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800/80 mt-3 flex items-center justify-between text-xs">
            <span className="text-[11px] text-slate-400">View sales register & bills</span>
            <button
              type="button"
              onClick={() => onNavigateToTab('bills_invoices')}
              className="text-cyan-400 hover:text-cyan-300 font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Open Sales Register</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
