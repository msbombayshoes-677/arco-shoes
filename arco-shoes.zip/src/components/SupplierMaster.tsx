import React, { useState, useEffect } from 'react';
import {
  Building2,
  Plus,
  Save,
  Trash2,
  Search,
  RotateCcw,
  Landmark,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  AlertCircle,
  Printer,
  Calendar,
  Lock,
  Unlock,
} from 'lucide-react';
import { Supplier, LedgerEntry } from '../types';
import { dbService } from '../services/storage';
import { INDIAN_STATES, formatCurrency, roundTo2 } from '../services/gstCalculations';
import { SuccessPopup } from './SuccessPopup';
import { ConfirmModal } from './ConfirmModal';
import { SupplierLedgerPrintModal, SupplierLedgerPrintRow } from './SupplierLedgerPrintModal';

export const SupplierMasterComponent: React.FC = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState<boolean>(false);

  // Print Statement State
  const [printSupplier, setPrintSupplier] = useState<Supplier | null>(null);
  const [printData, setPrintData] = useState<{
    openingBalance: number;
    rows: SupplierLedgerPrintRow[];
    periodTotalDebit: number;
    periodTotalCredit: number;
    closingBalance: number;
    fromDate: string;
    toDate: string;
  } | null>(null);

  // Form fields
  const [supplierCode, setSupplierCode] = useState<string>('');
  const [supplierName, setSupplierName] = useState<string>('');
  const [contactPerson, setContactPerson] = useState<string>('');
  const [mobile, setMobile] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [city, setCity] = useState<string>('');
  const [state, setState] = useState<string>('');
  const [stateCode, setStateCode] = useState<string>('');
  const [gstin, setGstin] = useState<string>('');
  const [pan, setPan] = useState<string>('');
  const [bankName, setBankName] = useState<string>('');
  const [bankAccountNo, setBankAccountNo] = useState<string>('');
  const [bankIfsc, setBankIfsc] = useState<string>('');
  const [openingDate, setOpeningDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [openingBalance, setOpeningBalance] = useState<number>(0);
  const [currentBalance, setCurrentBalance] = useState<number>(0);
  const [paymentTermsDays, setPaymentTermsDays] = useState<number>(30);
  const [isActive, setIsActive] = useState<boolean>(true);
  const [isCodeLocked, setIsCodeLocked] = useState<boolean>(true);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; title?: string; text: string } | null>(null);

  const loadSuppliers = () => {
    const list = dbService.getSuppliers();
    setSuppliers(list);
  };

  useEffect(() => {
    loadSuppliers();
  }, []);

  const resetForm = () => {
    setSelectedId(null);
    const count = suppliers.length + 1;
    setSupplierCode(`SUP-${String(count).padStart(3, '0')}`);
    setSupplierName('');
    setContactPerson('');
    setMobile('');
    setPhone('');
    setEmail('');
    setAddress('');
    setCity('');
    setState('');
    setStateCode('');
    setGstin('');
    setPan('');
    setBankName('');
    setBankAccountNo('');
    setBankIfsc('');
    setOpeningDate(new Date().toISOString().split('T')[0]);
    setOpeningBalance(0);
    setCurrentBalance(0);
    setPaymentTermsDays(30);
    setIsActive(true);
    setIsCodeLocked(true);
    setFeedback(null);
  };

  const handleOpenPrint = (targetSupplier: Supplier) => {
    const allLedgers = dbService.getLedgers();
    const allPayments = dbService.getPayments();
    const existingLedgerVoucherNos = new Set(
      allLedgers.map((l) => (l.voucherNo || '').trim().toUpperCase())
    );

    const missingPaymentLedgers: LedgerEntry[] = allPayments
      .filter((p) => {
        if (!p.voucherNo) return false;
        const vNo = p.voucherNo.trim().toUpperCase();
        if (existingLedgerVoucherNos.has(vNo)) return false;
        return (
          p.supplierId === targetSupplier.id ||
          p.supplierId === targetSupplier.supplierCode ||
          (p.supplierName && p.supplierName.trim().toLowerCase() === targetSupplier.supplierName.trim().toLowerCase())
        );
      })
      .map((p) => ({
        id: `LED-SP-${p.id}`,
        date: p.voucherDate,
        partyType: 'Supplier' as const,
        partyId: p.supplierId,
        partyName: p.supplierName,
        voucherType: 'Payment',
        voucherNo: p.voucherNo,
        debit: (p.amountPaid || 0) + (p.discountReceived || 0),
        credit: 0,
        runningBalance: p.newBalance || 0,
        narration: `Payment issued to Supplier (${p.paymentMode || 'Cash'}) Ref: ${p.referenceNo || 'Direct'}`,
      }));

    const supLedgers = [...allLedgers, ...missingPaymentLedgers].filter(
      (l) =>
        l.partyType === 'Supplier' &&
        (l.partyId === targetSupplier.id ||
          l.partyId === targetSupplier.supplierCode ||
          (l.partyName && l.partyName.trim().toLowerCase() === targetSupplier.supplierName.trim().toLowerCase()))
    );

    const fromDate = '2026-04-01';
    const toDate = '2027-03-31';
    const preDateEntries = supLedgers.filter((l) => l.date < fromDate);
    const preDebit = preDateEntries.reduce((sum, l) => sum + (l.debit || 0), 0);
    const preCredit = preDateEntries.reduce((sum, l) => sum + (l.credit || 0), 0);
    const openingBal = roundTo2((targetSupplier.openingBalance || 0) + preCredit - preDebit);

    const periodEntries = supLedgers
      .filter((l) => l.date >= fromDate && l.date <= toDate)
      .sort((a, b) => a.date.localeCompare(b.date));

    let running = openingBal;
    const rowsWithBalance: SupplierLedgerPrintRow[] = periodEntries.map((entry) => {
      running = roundTo2(running + (entry.credit || 0) - (entry.debit || 0));
      return {
        id: entry.id,
        date: entry.date,
        voucherType: entry.voucherType,
        voucherNo: entry.voucherNo,
        narration: entry.narration,
        debit: entry.debit || 0,
        credit: entry.credit || 0,
        calculatedBalance: running,
      };
    });

    const periodTotalDebit = roundTo2(periodEntries.reduce((sum, l) => sum + (l.debit || 0), 0));
    const periodTotalCredit = roundTo2(periodEntries.reduce((sum, l) => sum + (l.credit || 0), 0));
    const closingBal = rowsWithBalance.length > 0
      ? rowsWithBalance[rowsWithBalance.length - 1].calculatedBalance
      : openingBal;

    setPrintSupplier(targetSupplier);
    setPrintData({
      openingBalance: openingBal,
      rows: rowsWithBalance,
      periodTotalDebit,
      periodTotalCredit,
      closingBalance: closingBal,
      fromDate,
      toDate,
    });
  };

  const handleSelectSupplier = (s: Supplier) => {
    setSelectedId(s.id);
    setSupplierCode(s.supplierCode);
    setSupplierName(s.supplierName);
    setContactPerson(s.contactPerson || '');
    setMobile(s.mobile || '');
    setPhone(s.phone || '');
    setEmail(s.email || '');
    setAddress(s.address || '');
    setCity(s.city || '');
    setState(s.state || '');
    setStateCode(s.stateCode || '');
    setGstin(s.gstin || '');
    setPan(s.pan || '');
    setBankName(s.bankName || '');
    setBankAccountNo(s.bankAccountNo || '');
    setBankIfsc(s.bankIfsc || '');
    setOpeningDate(s.openingDate || s.createdAt || new Date().toISOString().split('T')[0]);
    setOpeningBalance(s.openingBalance || 0);
    setCurrentBalance(s.currentBalance || 0);
    setPaymentTermsDays(s.paymentTermsDays || 30);
    setIsActive(s.isActive);
    setIsCodeLocked(true);
    setFeedback(null);
  };

  const handleStateChange = (selectedStateName: string) => {
    setState(selectedStateName);
    const st = INDIAN_STATES.find((s) => s.name === selectedStateName);
    if (st) {
      setStateCode(st.code);
    } else {
      setStateCode('');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplierName.trim()) {
      setFeedback({ type: 'error', title: 'Validation Required', text: 'Supplier Name is required.' });
      return;
    }

    const isUpdate = Boolean(selectedId);
    const supplier: Supplier = {
      id: selectedId || `SUP-${Date.now()}`,
      supplierCode: supplierCode.trim().toUpperCase() || `SUP-${Date.now()}`,
      supplierName: supplierName.trim(),
      contactPerson: contactPerson.trim(),
      mobile: mobile.trim(),
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      city: city.trim(),
      state,
      stateCode,
      gstin: gstin.trim().toUpperCase(),
      pan: pan.trim().toUpperCase(),
      bankName: bankName.trim(),
      bankAccountNo: bankAccountNo.trim(),
      bankIfsc: bankIfsc.trim().toUpperCase(),
      openingDate: openingDate || new Date().toISOString().split('T')[0],
      openingBalance: Number(openingBalance) || 0,
      currentBalance: selectedId ? Number(currentBalance) : Number(openingBalance) || 0,
      paymentTermsDays: Number(paymentTermsDays) || 0,
      isActive,
      createdAt: selectedId ? suppliers.find((s) => s.id === selectedId)?.createdAt || '' : new Date().toISOString().split('T')[0],
    };

    dbService.saveSupplier(supplier);
    loadSuppliers();
    setFeedback({
      type: 'success',
      title: isUpdate ? 'Supplier Updated Successfully' : 'Supplier Saved Successfully',
      text: isUpdate
        ? `Supplier "${supplier.supplierName}" has been updated successfully!`
        : `Supplier "${supplier.supplierName}" has been saved successfully!`,
    });
    if (!selectedId) {
      resetForm();
    }
  };

  const handleDelete = () => {
    if (!selectedId) return;
    setShowConfirmDelete(true);
  };

  const confirmDeleteSupplier = () => {
    if (!selectedId) return;
    const res = dbService.deleteSupplier(selectedId);
    setShowConfirmDelete(false);
    if (res.success) {
      setFeedback({
        type: 'success',
        title: 'Supplier Deleted Successfully',
        text: res.message,
      });
      loadSuppliers();
      resetForm();
    } else {
      setFeedback({ type: 'error', title: 'Delete Operation Failed', text: res.message });
    }
  };

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.supplierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.supplierCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.mobile && s.mobile.includes(searchQuery)) ||
      (s.gstin && s.gstin.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="p-3 sm:p-5 max-w-7xl mx-auto space-y-4 font-sans select-none">
      {/* Confirmation Modal */}
      {showConfirmDelete && (
        <ConfirmModal
          title="Delete Supplier Account"
          message="Are you sure you want to delete this supplier account? This action cannot be undone."
          confirmLabel="Delete Supplier"
          onConfirm={confirmDeleteSupplier}
          onCancel={() => setShowConfirmDelete(false)}
        />
      )}

      {/* Modal Popup for all Messages */}
      {feedback && (
        <SuccessPopup
          type={feedback.type}
          title={feedback.title}
          message={feedback.text}
          onClose={() => setFeedback(null)}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Supplier Form Panel (frmSupplierMaster) */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100">
          <div className="flex items-center justify-between border-b border-slate-700/40 pb-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-orange-600/20 text-orange-400 border border-orange-500/30 flex items-center justify-center shadow-inner">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-bold text-base text-slate-100 flex items-center gap-2">
                  <span>{selectedId ? 'Edit Supplier' : 'Supplier Account Master'}</span>
                </h2>
                <p className="text-xs text-slate-400">Manufacturer/Distributor details & payables</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {selectedId && (
                <button
                  id="btn-print-supplier-statement"
                  type="button"
                  onClick={() => {
                    const current = suppliers.find((s) => s.id === selectedId);
                    if (current) handleOpenPrint(current);
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700/60 backdrop-blur-sm transition cursor-pointer"
                  title="Print Statement of Account"
                >
                  <Printer className="w-3.5 h-3.5 text-orange-400" />
                  <span>Print Statement</span>
                </button>
              )}

              <button
                id="btn-new-supplier"
                type="button"
                onClick={resetForm}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 text-xs font-medium border border-slate-700/50 backdrop-blur-sm transition"
              >
                <RotateCcw className="w-3.5 h-3.5 text-orange-400" />
                <span>New</span>
              </button>
            </div>
          </div>

          <form id="form-supplier-master" onSubmit={handleSave} className="space-y-3 text-xs">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-400 font-medium flex items-center gap-1">
                    <span>Supplier Code</span>
                    <span
                      className={`inline-flex items-center gap-0.5 text-[9px] font-semibold px-1 py-0.2 rounded border ${
                        isCodeLocked
                          ? 'bg-orange-950/60 text-orange-300 border-orange-500/40'
                          : 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                      }`}
                    >
                      {isCodeLocked ? <Lock className="w-2.5 h-2.5" /> : <Unlock className="w-2.5 h-2.5" />}
                      {isCodeLocked ? 'Locked' : 'Open'}
                    </span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsCodeLocked(!isCodeLocked)}
                    className="text-[10px] text-slate-400 hover:text-orange-300 flex items-center gap-0.5 transition-colors cursor-pointer"
                    title={isCodeLocked ? 'Click to unlock Supplier Code' : 'Click to lock Supplier Code'}
                  >
                    {isCodeLocked ? (
                      <>
                        <Unlock className="w-3 h-3 text-slate-400" />
                        <span className="hidden sm:inline">Unlock</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3 h-3 text-orange-400" />
                        <span className="text-orange-400 font-medium hidden sm:inline">Lock</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    required
                    readOnly={isCodeLocked}
                    value={supplierCode}
                    onChange={(e) => setSupplierCode(e.target.value)}
                    placeholder="SUP-001"
                    className={`w-full rounded-lg px-2.5 py-1.5 font-mono font-bold uppercase transition-all ${
                      isCodeLocked
                        ? 'bg-slate-900/85 border border-slate-700/60 text-slate-300 cursor-not-allowed select-all pr-7'
                        : 'bg-slate-950/70 border border-orange-500/80 text-slate-100 focus:border-orange-400 focus:outline-none'
                    }`}
                  />
                  {isCodeLocked && (
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none">
                      <Lock className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>
              </div>

              <div className="col-span-2">
                <label className="block text-slate-400 font-medium mb-1">Supplier / Firm Name *</label>
                <input
                  type="text"
                  required
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  placeholder="Leathercraft Tanneries Ltd."
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-semibold focus:border-orange-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="Mr. Vivek Mathur"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Mobile No.</label>
                <input
                  type="text"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  placeholder="9837012345"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono focus:border-orange-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Factory / Office Address</label>
              <textarea
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Plot 45, Leather Industrial Zone, Sikandra"
                className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg p-2 text-slate-100 focus:border-orange-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">State</label>
                <select
                  value={state}
                  onChange={(e) => handleStateChange(e.target.value)}
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-1.5 py-1.5 text-slate-100 focus:border-orange-500 focus:outline-none text-xs"
                >
                  <option value="">Select State</option>
                  {INDIAN_STATES.map((s) => (
                    <option key={s.code} value={s.name}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">GST State Code</label>
                <input
                  type="text"
                  readOnly
                  value={stateCode}
                  className="w-full bg-slate-900/80 border border-slate-700/60 rounded-lg px-2 py-1.5 text-orange-400 font-mono font-bold text-center"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Supplier GSTIN (15 Digit)</label>
                <input
                  type="text"
                  maxLength={15}
                  value={gstin}
                  onChange={(e) => setGstin(e.target.value.toUpperCase())}
                  placeholder="09AABCL8890P1ZN"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase focus:border-orange-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">PAN No.</label>
                <input
                  type="text"
                  maxLength={10}
                  value={pan}
                  onChange={(e) => setPan(e.target.value.toUpperCase())}
                  placeholder="AABCL8890P"
                  className="w-full bg-slate-950/70 border border-slate-700/60 rounded-lg px-2.5 py-1.5 text-slate-100 font-mono uppercase focus:border-orange-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Bank Details & Khata */}
            <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-700/40 space-y-2 backdrop-blur-xs">
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider block">
                Bank & Payment Terms
              </span>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Bank Name</label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="PNB / HDFC"
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">A/C Number</label>
                  <input
                    type="text"
                    value={bankAccountNo}
                    onChange={(e) => setBankAccountNo(e.target.value)}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-orange-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">IFSC Code</label>
                  <input
                    type="text"
                    value={bankIfsc}
                    onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono uppercase focus:border-orange-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Account Opening Date</label>
                  <input
                    type="date"
                    id="supplier-opening-date"
                    value={openingDate}
                    onChange={(e) => setOpeningDate(e.target.value)}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono focus:border-orange-500 focus:outline-none text-xs"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-0.5">Opening Payable Bal (₹)</label>
                  <input
                    type="number"
                    disabled={Boolean(selectedId)}
                    value={openingBalance}
                    onChange={(e) => {
                      setOpeningBalance(Number(e.target.value));
                      if (!selectedId) setCurrentBalance(Number(e.target.value));
                    }}
                    className="w-full bg-slate-900/80 border border-slate-700/60 rounded px-2 py-1 text-slate-100 font-mono disabled:opacity-50 focus:border-orange-500 focus:outline-none text-xs"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-700/40">
              {selectedId ? (
                <button
                  type="button"
                  onClick={handleDelete}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-semibold backdrop-blur-sm transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              ) : (
                <div />
              )}

              <button
                id="btn-save-supplier-master"
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg shadow-lg shadow-orange-900/20 border border-orange-500/30 transition"
              >
                <Save className="w-4 h-4" />
                <span>{selectedId ? 'Update Supplier' : 'Save Supplier [F10]'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Suppliers Directory Table */}
        <div className="lg:col-span-7 bg-slate-900/40 border border-slate-700/50 rounded-xl p-4 shadow-xl backdrop-blur-md text-slate-100 flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700/40 pb-3 mb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <span>Supplier / Vendor Directory</span>
                <span className="bg-slate-800/60 text-orange-400 font-mono text-xs px-2 py-0.5 rounded border border-slate-700/50">
                  {filteredSuppliers.length} vendors
                </span>
              </h3>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search vendor name/code/GSTIN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950/70 border border-slate-700/60 rounded-lg pl-8 pr-2.5 py-1 text-slate-200 text-xs focus:border-orange-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto flex-1 max-h-[520px] rounded-lg border border-slate-700/40 bg-slate-900/20 backdrop-blur-xs">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 sticky top-0 backdrop-blur-md z-10">
                <tr>
                  <th className="py-2.5 px-2.5">Code</th>
                  <th className="py-2.5 px-2">Supplier Name</th>
                  <th className="py-2.5 px-2">Mobile / City</th>
                  <th className="py-2.5 px-2 text-center">GSTIN</th>
                  <th className="py-2.5 px-2 text-right">Payable Balance (Cr)</th>
                  <th className="py-2.5 px-2 text-center w-14">Print</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredSuppliers.map((s) => {
                  const isSelected = selectedId === s.id;
                  return (
                    <tr
                      key={s.id}
                      onClick={() => handleSelectSupplier(s)}
                      className={`cursor-pointer transition ${
                        isSelected
                          ? 'bg-orange-950/40 border-l-4 border-orange-500 text-slate-100'
                          : 'hover:bg-slate-800/40 text-slate-300'
                      }`}
                    >
                      <td className="py-2.5 px-2.5 font-mono font-bold text-orange-400">{s.supplierCode}</td>
                      <td className="py-2.5 px-2 font-medium">
                        <div className="text-slate-100">{s.supplierName}</div>
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] text-slate-400">
                          {s.contactPerson && <span>Attn: {s.contactPerson}</span>}
                          {s.openingDate && (
                            <span className="text-orange-400/90 font-mono">
                              Opened: {s.openingDate}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-2.5 px-2">
                        <div className="font-mono">{s.mobile || '-'}</div>
                        <div className="text-[10px] text-slate-400">{s.city}, {s.stateCode}</div>
                      </td>
                      <td className="py-2.5 px-2 text-center font-mono text-[11px]">
                        {s.gstin ? <span className="text-emerald-400 font-semibold">{s.gstin}</span> : <span className="text-slate-500">Unregistered</span>}
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono font-bold text-orange-400 text-sm">
                        {formatCurrency(s.currentBalance)}
                      </td>
                      <td className="py-2.5 px-2 text-center" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => handleOpenPrint(s)}
                          title={`Print Statement for ${s.supplierName}`}
                          className="p-1 rounded bg-slate-800/80 hover:bg-orange-600 text-slate-300 hover:text-white border border-slate-700/60 transition cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Supplier Ledger Print Modal */}
      {printSupplier && printData && (
        <SupplierLedgerPrintModal
          company={dbService.getCompanyInfo()}
          supplier={printSupplier}
          fromDate={printData.fromDate}
          toDate={printData.toDate}
          openingBalance={printData.openingBalance}
          rows={printData.rows}
          periodTotalDebit={printData.periodTotalDebit}
          periodTotalCredit={printData.periodTotalCredit}
          closingBalance={printData.closingBalance}
          onClose={() => {
            setPrintSupplier(null);
            setPrintData(null);
          }}
        />
      )}
    </div>
  );
};
