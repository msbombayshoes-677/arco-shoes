import React, { useState, useEffect } from 'react';
import {
  Cloud,
  Database,
  Download,
  Upload,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Archive,
  FileSpreadsheet,
  FileText,
  ShieldCheck,
  Trash2,
  RotateCcw,
  Sparkles,
  Info,
  Server,
  Layers,
  X,
} from 'lucide-react';
import { CloudBackupRecord, AutoBackupScheduleConfig, WeekDay } from '../types';
import { backupService } from '../services/backupService';
import { BACKEND_DETAILS } from '../firebase';
import { GoogleDriveBackupSection } from './GoogleDriveBackupSection';
import { HardDrive } from 'lucide-react';

const WEEK_DAYS: WeekDay[] = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

export const BackupArchiveComponent: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'gdrive' | 'snapshots'>('gdrive');
  const [backups, setBackups] = useState<CloudBackupRecord[]>([]);
  const [scheduleConfig, setScheduleConfig] = useState<AutoBackupScheduleConfig>(() =>
    backupService.getScheduleConfig()
  );
  const [isCreatingSnapshot, setIsCreatingSnapshot] = useState(false);
  const [selectedRestoreBackup, setSelectedRestoreBackup] = useState<CloudBackupRecord | null>(null);
  const [snapshotToDelete, setSnapshotToDelete] = useState<CloudBackupRecord | null>(null);
  const [showDeleteAllModal, setShowDeleteAllModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [notesInput, setNotesInput] = useState('');

  useEffect(() => {
    const unsubscribe = backupService.subscribe((updated) => {
      setBackups(updated);
    });
    return () => unsubscribe();
  }, []);

  const handleSaveSchedule = () => {
    backupService.saveScheduleConfig(scheduleConfig);
    const timeStr = scheduleConfig.scheduledTime || scheduleConfig.dailyTime || '23:00';
    let freqSummary = '';
    if (scheduleConfig.frequency === 'DAILY') {
      freqSummary = `Daily at ${timeStr}`;
    } else if (scheduleConfig.frequency === 'WEAKLY' || scheduleConfig.frequency === 'WEEKLY') {
      freqSummary = `Weakly on ${scheduleConfig.weekDay || 'Sunday'} at ${timeStr} (every 7th day)`;
    } else if (scheduleConfig.frequency === 'MONTHLY') {
      freqSummary = `Monthly on ${scheduleConfig.weekDay || 'Sunday'} at ${timeStr}`;
    } else {
      freqSummary = `${scheduleConfig.frequency} at ${timeStr}`;
    }

    setFeedback({
      type: 'success',
      message: `Automated backup schedule updated! Backup Frequency: ${freqSummary}`,
    });
    setTimeout(() => setFeedback(null), 4500);
  };

  const handleCreateSnapshot = async () => {
    if (!scheduleConfig.enabled) {
      setFeedback({
        type: 'error',
        message: 'Cloud Backups are currently DISABLED. Enable the Cloud Backup slide switch at the top near Offline JSON Archive to take backups.',
      });
      setTimeout(() => setFeedback(null), 5000);
      return;
    }
    setIsCreatingSnapshot(true);
    try {
      const record = await backupService.createCloudSnapshot('MANUAL', notesInput.trim() || undefined);
      setNotesInput('');
      setFeedback({
        type: 'success',
        message: `Cloud snapshot created successfully! Preserved ${record.totalRecords} records (${(record.sizeBytes / 1024).toFixed(1)} KB).`,
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Failed to create snapshot: ${err.message || err}`,
      });
    } finally {
      setIsCreatingSnapshot(false);
      setTimeout(() => setFeedback(null), 5000);
    }
  };

  const handleConfirmRestore = () => {
    if (!selectedRestoreBackup) return;
    setIsRestoring(true);
    try {
      const res = backupService.restoreFromSnapshot(selectedRestoreBackup.id);
      if (res.success) {
        setFeedback({
          type: 'success',
          message: `Database restored successfully to snapshot from ${new Date(selectedRestoreBackup.timestamp).toLocaleString()}!`,
        });
        setSelectedRestoreBackup(null);
      } else {
        setFeedback({
          type: 'error',
          message: res.message,
        });
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Restore failed: ${err.message || err}`,
      });
    } finally {
      setIsRestoring(false);
      setTimeout(() => setFeedback(null), 5000);
    }
  };

  const handleConfirmDeleteSnapshot = async () => {
    if (!snapshotToDelete) return;
    setIsDeleting(true);
    try {
      await backupService.deleteSnapshot(snapshotToDelete.id);
      setFeedback({
        type: 'success',
        message: `Snapshot from ${new Date(snapshotToDelete.timestamp).toLocaleString()} deleted successfully from active list.`,
      });
      setSnapshotToDelete(null);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Failed to delete snapshot: ${err.message || err}`,
      });
    } finally {
      setIsDeleting(false);
      setTimeout(() => setFeedback(null), 4000);
    }
  };

  const handleConfirmDeleteAll = async () => {
    setIsDeleting(true);
    try {
      await backupService.deleteAllSnapshots();
      setFeedback({
        type: 'success',
        message: 'All stored cloud snapshots and archives have been deleted successfully.',
      });
      setShowDeleteAllModal(false);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `Failed to delete snapshots: ${err.message || err}`,
      });
    } finally {
      setIsDeleting(false);
      setTimeout(() => setFeedback(null), 4000);
    }
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto">
      {/* Top Header Card */}
      <div className="bg-slate-900/60 border border-slate-700/60 rounded-2xl p-5 shadow-xl backdrop-blur-md text-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-teal-600/20 text-teal-400 border border-teal-500/30 flex items-center justify-center shadow-inner">
            <Cloud className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tight text-white">Cloud Settings</h1>
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 ${
                  scheduleConfig.enabled
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    scheduleConfig.enabled ? 'bg-teal-400 animate-pulse' : 'bg-rose-400'
                  }`}
                />
                {scheduleConfig.enabled ? 'Snapshot Engine Active' : 'Snapshot Engine Disabled'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Scheduled automated database snapshots with one-click offline JSON and multi-sheet Excel archive export.
            </p>
          </div>
        </div>

        {/* Quick Offline Export Buttons & Master Cloud Backup Slide Toggle */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Enable / Disable Slide Toggle Button */}
          <div className="flex items-center gap-2.5 px-3.5 py-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl shadow-inner">
            <span className="text-xs font-bold text-slate-200">
              Cloud Backup:{' '}
              <span className={scheduleConfig.enabled ? 'text-teal-400 font-extrabold' : 'text-rose-400 font-extrabold'}>
                {scheduleConfig.enabled ? 'Enabled' : 'Disabled'}
              </span>
            </span>
            <label className="relative inline-flex items-center cursor-pointer select-none">
              <input
                type="checkbox"
                checked={scheduleConfig.enabled}
                onChange={(e) => {
                  const isEnabled = e.target.checked;
                  const updated = { ...scheduleConfig, enabled: isEnabled };
                  setScheduleConfig(updated);
                  backupService.saveScheduleConfig(updated);
                  setFeedback({
                    type: isEnabled ? 'success' : 'error',
                    message: isEnabled
                      ? 'Cloud Backups are now ENABLED. Automatic and manual cloud snapshots will be taken.'
                      : 'Cloud Backups are now DISABLED. Automatic and manual cloud snapshots will NOT be taken.',
                  });
                  setTimeout(() => setFeedback(null), 4000);
                }}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-500"></div>
            </label>
          </div>

          <button
            onClick={() => backupService.downloadOfflineJsonArchive()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition shadow cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Offline JSON Archive</span>
          </button>

          <button
            onClick={() => backupService.downloadOfflineExcelArchive()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-900/20 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Offline Excel Workbook (.xls)</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 animate-in fade-in ${
            feedback.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Sub-tab Navigation */}
      <div className="flex items-center gap-2.5 border-b border-slate-800/80 pb-2">
        <button
          type="button"
          onClick={() => setActiveSubTab('gdrive')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition cursor-pointer border ${
            activeSubTab === 'gdrive'
              ? 'bg-blue-600/20 text-blue-300 border-blue-500/50 shadow-lg shadow-blue-950/30'
              : 'bg-slate-900/40 text-slate-400 border-slate-800/80 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <HardDrive className="w-4 h-4 text-blue-400" />
          <span>Google Drive</span>
          <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
            OAuth 2.0
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('snapshots')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition cursor-pointer border ${
            activeSubTab === 'snapshots'
              ? 'bg-teal-600/20 text-teal-300 border-teal-500/50 shadow-lg shadow-teal-950/30'
              : 'bg-slate-900/40 text-slate-400 border-slate-800/80 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
        >
          <Cloud className="w-4 h-4 text-teal-400" />
          <span>Automated Snapshots & Schedule</span>
          <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30 font-mono">
            {backups.length}
          </span>
        </button>
      </div>

      {/* Tab 1: Google Drive */}
      {activeSubTab === 'gdrive' && <GoogleDriveBackupSection />}

      {/* Tab 2: Automated Snapshots & Stored Archives */}
      {activeSubTab === 'snapshots' && (
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Schedule & Create Controls */}
        <div className="lg:col-span-5 space-y-4">
          {/* Create Manual Snapshot Card */}
          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 shadow-xl text-slate-100 space-y-3">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Sparkles className="w-4 h-4 text-teal-400" />
              <h2 className="font-bold text-sm text-white">Create Cloud Snapshot Now</h2>
            </div>
            <p className="text-xs text-slate-400">
              Immediately capture an immutable snapshot of all sales invoices, catalog items, khata ledgers, and stock adjustments.
            </p>

            <div className="space-y-2">
              <label className="text-[11px] font-semibold text-slate-300 block">Snapshot Note (Optional)</label>
              <input
                type="text"
                value={notesInput}
                onChange={(e) => setNotesInput(e.target.value)}
                placeholder="e.g. Month-end audit backup / Pre-inventory reconciliation"
                className="w-full px-3 py-1.5 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            <button
              onClick={handleCreateSnapshot}
              disabled={isCreatingSnapshot}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow cursor-pointer"
            >
              <Cloud className={`w-4 h-4 ${isCreatingSnapshot ? 'animate-bounce' : ''}`} />
              <span>{isCreatingSnapshot ? 'Creating Cloud Snapshot...' : 'Take Cloud Snapshot Now'}</span>
            </button>
          </div>

          {/* Automated Schedule & Retention Card */}
          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 shadow-xl text-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <h2 className="font-bold text-sm text-white">Automated Snapshot Schedule</h2>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={scheduleConfig.enabled}
                  onChange={(e) => setScheduleConfig({ ...scheduleConfig, enabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-600"></div>
              </label>
            </div>

            <div className="space-y-3.5 text-xs">
              {/* Backup Frequency Dropdown */}
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                  Backup Frequency
                </label>
                <select
                  value={scheduleConfig.frequency}
                  onChange={(e) => {
                    const nextFreq = e.target.value;
                    setScheduleConfig({ ...scheduleConfig, frequency: nextFreq });
                  }}
                  className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-500 cursor-pointer"
                >
                  <option value="DAILY">Daily</option>
                  <option value="WEAKLY">Weakly</option>
                  <option value="MONTHLY">monthly</option>
                </select>
              </div>

              {/* Week Day Dropdown */}
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1 flex items-center justify-between">
                  <span>Week Day</span>
                  {scheduleConfig.frequency === 'DAILY' && (
                    <span className="text-[10px] text-slate-500 font-normal">(Used for Weakly / Monthly schedules)</span>
                  )}
                </label>
                <select
                  value={scheduleConfig.weekDay || 'Sunday'}
                  onChange={(e) =>
                    setScheduleConfig({ ...scheduleConfig, weekDay: e.target.value as WeekDay })
                  }
                  className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-500 cursor-pointer"
                >
                  {WEEK_DAYS.map((day) => (
                    <option key={day} value={day}>
                      {day}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">
                  Select the day on which the backup will be created.
                </p>
              </div>

              {/* Scheduled Time Input */}
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                  Scheduled Time
                </label>
                <input
                  type="time"
                  value={scheduleConfig.scheduledTime || scheduleConfig.dailyTime || '23:00'}
                  onChange={(e) => {
                    const newTime = e.target.value;
                    setScheduleConfig({
                      ...scheduleConfig,
                      scheduledTime: newTime,
                      dailyTime: newTime,
                    });
                  }}
                  className="w-full px-3 py-2 bg-slate-950/70 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-500"
                />
              </div>

              {/* Schedule Description Pill */}
              <div className="p-3 bg-teal-950/30 border border-teal-500/20 rounded-xl space-y-1 text-[11px]">
                <div className="font-semibold text-teal-300 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                  <span>Schedule Execution Policy</span>
                </div>
                {scheduleConfig.frequency === 'DAILY' && (
                  <p className="text-slate-300 leading-relaxed">
                    In case of <strong>Daily</strong>: Auto-backup will create once scheduled time (
                    <span className="text-teal-300 font-mono font-bold">
                      {scheduleConfig.scheduledTime || scheduleConfig.dailyTime || '23:00'}
                    </span>
                    ) is reached.
                  </p>
                )}
                {(scheduleConfig.frequency === 'WEAKLY' || scheduleConfig.frequency === 'WEEKLY') && (
                  <p className="text-slate-300 leading-relaxed">
                    In case of <strong>Weakly</strong>: Auto-backup will create once scheduled time (
                    <span className="text-teal-300 font-mono font-bold">
                      {scheduleConfig.scheduledTime || scheduleConfig.dailyTime || '23:00'}
                    </span>
                    ) is reached on <span className="text-teal-300 font-bold">{scheduleConfig.weekDay || 'Sunday'}</span> and number of days will be after every 7th day.
                  </p>
                )}
                {scheduleConfig.frequency === 'MONTHLY' && (
                  <p className="text-slate-300 leading-relaxed">
                    In case of <strong>Monthly</strong>: Auto-backup will create once in every month on scheduled time (
                    <span className="text-teal-300 font-mono font-bold">
                      {scheduleConfig.scheduledTime || scheduleConfig.dailyTime || '23:00'}
                    </span>
                    ) and week day (<span className="text-teal-300 font-bold">{scheduleConfig.weekDay || 'Sunday'}</span>).
                  </p>
                )}
              </div>

              {scheduleConfig.lastBackupAt && (
                <div className="p-2.5 bg-slate-950/50 rounded-lg border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Last Automated Run:</span>
                  <span className="font-mono text-slate-200">
                    {new Date(scheduleConfig.lastBackupAt).toLocaleString()}
                  </span>
                </div>
              )}

              <button
                onClick={handleSaveSchedule}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-teal-400 hover:text-teal-300 border border-teal-500/30 rounded-lg text-xs font-bold transition cursor-pointer"
              >
                Save Schedule Settings
              </button>
            </div>
          </div>

          {/* Database Target Info Box */}
          <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 space-y-2">
            <div className="flex items-center gap-2 font-bold text-slate-300">
              <Server className="w-4 h-4 text-teal-400" />
              <span>Target Cloud Destination</span>
            </div>
            <div className="space-y-1 text-[11px]">
              <div>
                Firestore Project:{' '}
                <span className="font-mono text-slate-200">{BACKEND_DETAILS.projectId}</span>
              </div>
              <div>
                Database ID:{' '}
                <span className="font-mono text-slate-200">{BACKEND_DETAILS.firestoreDatabaseId}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: List of Snapshots */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-5 shadow-xl text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Archive className="w-4 h-4 text-teal-400" />
                <h2 className="font-bold text-sm text-white">Stored Cloud Snapshots & Archives</h2>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-teal-400 border border-slate-700">
                  {backups.length} Available
                </span>
                {backups.length > 0 && (
                  <button
                    onClick={() => setShowDeleteAllModal(true)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-[11px] font-bold transition cursor-pointer"
                    title="Delete all cloud snapshots"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Delete All</span>
                  </button>
                )}
              </div>
            </div>

            {/* List */}
            <div className="space-y-3 mt-4 max-h-[580px] overflow-y-auto pr-1">
              {backups.length === 0 ? (
                <div className="py-12 text-center text-slate-500">
                  <Cloud className="w-8 h-8 mx-auto text-slate-600 mb-2 opacity-60" />
                  <p className="font-semibold text-slate-400">No cloud snapshots in active list</p>
                  <p className="text-[11px] mt-1 text-slate-600">
                    Click "Take Cloud Snapshot Now" to create a new database snapshot.
                  </p>
                </div>
              ) : (
                backups.map((b) => {
                  const bDate = new Date(b.timestamp);
                  return (
                    <div
                      key={b.id}
                      className="p-4 rounded-xl border border-slate-800 bg-slate-950/50 hover:bg-slate-900/40 transition-all space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-xs text-white">
                              {bDate.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })} at{' '}
                              {bDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                            <span
                              className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                                b.type === 'AUTOMATED'
                                  ? 'bg-teal-500/20 text-teal-300 border-teal-500/30'
                                  : 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                              }`}
                            >
                              {b.type}
                            </span>
                            <span className="text-[9px] font-mono text-slate-400">
                              {(b.sizeBytes / 1024).toFixed(1)} KB
                            </span>
                          </div>
                          {b.notes && (
                            <p className="text-[11px] text-slate-400 mt-1 italic">
                              "{b.notes}"
                            </p>
                          )}
                        </div>

                        {/* Action buttons (Unrestricted Delete & Restore) */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => setSelectedRestoreBackup(b)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-600/20 hover:bg-amber-600/40 text-amber-300 border border-amber-500/30 text-[11px] font-bold transition cursor-pointer"
                            title="Restore this snapshot"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Restore</span>
                          </button>

                          <button
                            onClick={() => setSnapshotToDelete(b)}
                            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-rose-950/30 hover:bg-rose-900/50 text-rose-400 border border-rose-900/40 hover:border-rose-700 text-[11px] font-semibold transition cursor-pointer"
                            title="Delete snapshot without restriction"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </div>

                      {/* Record counts pills */}
                      <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-slate-900 text-[10px]">
                        <span className="text-slate-400 font-semibold">
                          Total: <strong className="text-white">{b.totalRecords}</strong> records
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                          {b.counts.sales} Sales
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                          {b.counts.items} Items
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                          {b.counts.customers} Customers
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                          {b.counts.suppliers} Suppliers
                        </span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                          {b.counts.adjustments} Stock Adjustments
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
      )}

      {/* Single Snapshot Delete Confirmation Modal */}
      {snapshotToDelete && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 text-slate-100">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Delete Cloud Snapshot</h3>
                <p className="text-xs text-slate-400">Permanently remove snapshot from active list</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to delete the snapshot from{' '}
              <strong className="text-white">
                {new Date(snapshotToDelete.timestamp).toLocaleString()}
              </strong>{' '}
              ({snapshotToDelete.totalRecords} records, {(snapshotToDelete.sizeBytes / 1024).toFixed(1)} KB)?
            </p>

            <div className="p-3 bg-rose-950/30 border border-rose-500/30 rounded-xl text-[11px] text-rose-300">
              <strong>Note:</strong> This snapshot will be removed immediately without any restrictions.
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSnapshotToDelete(null)}
                className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDeleteSnapshot}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <Trash2 className={`w-3.5 h-3.5 ${isDeleting ? 'animate-spin' : ''}`} />
                <span>{isDeleting ? 'Deleting...' : 'Delete Snapshot'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete All Snapshots Confirmation Modal */}
      {showDeleteAllModal && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/50 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 text-slate-100">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Delete All Cloud Snapshots</h3>
                <p className="text-xs text-slate-400">Purge all {backups.length} snapshots in active list</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to permanently delete all{' '}
              <strong className="text-rose-400">{backups.length}</strong> cloud snapshots and archives from the list?
            </p>

            <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl text-[11px] text-rose-300">
              <strong>Warning:</strong> This will delete all active snapshot history. New snapshots can be generated at any time.
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowDeleteAllModal(false)}
                className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isDeleting}
                onClick={handleConfirmDeleteAll}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <Trash2 className={`w-3.5 h-3.5 ${isDeleting ? 'animate-spin' : ''}`} />
                <span>{isDeleting ? 'Deleting All...' : 'Delete All Snapshots'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Restore Confirmation Modal */}
      {selectedRestoreBackup && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 text-slate-100">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Confirm Database Restore</h3>
                <p className="text-xs text-slate-400">Recovery to selected point in time</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              You are about to restore the ERP database to the snapshot taken on{' '}
              <strong className="text-white">
                {new Date(selectedRestoreBackup.timestamp).toLocaleString()}
              </strong>
              .
            </p>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 text-xs text-slate-300">
              <div className="font-semibold text-amber-400 mb-1">Records to be Restored:</div>
              <div>• {selectedRestoreBackup.counts.sales} Sales Invoices</div>
              <div>• {selectedRestoreBackup.counts.items} Item Master Catalog Records</div>
              <div>• {selectedRestoreBackup.counts.customers} Customer Khata Accounts</div>
              <div>• {selectedRestoreBackup.counts.suppliers} Supplier Accounts</div>
              <div>• {selectedRestoreBackup.counts.adjustments} Stock Adjustments</div>
            </div>

            <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl text-[11px] text-amber-300">
              <strong>Notice:</strong> Restoring will update items, customers, suppliers, and transaction records to match this snapshot.
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedRestoreBackup(null)}
                className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isRestoring}
                onClick={handleConfirmRestore}
                className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow"
              >
                <RotateCcw className={`w-3.5 h-3.5 ${isRestoring ? 'animate-spin' : ''}`} />
                <span>{isRestoring ? 'Restoring Database...' : 'Confirm & Restore'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
