import React, { useState } from 'react';
import {
  Cloud,
  Download,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
} from 'lucide-react';
import { backupService } from '../services/backupService';
import { GoogleDriveBackupSection } from './GoogleDriveBackupSection';

export const BackupArchiveComponent: React.FC = () => {
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  return (
    <div className="space-y-5 max-w-7xl mx-auto">
      {/* Top Header Card */}
      <div className="bg-slate-900/60 border border-slate-700/60 rounded-2xl p-5 shadow-xl backdrop-blur-md text-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shadow-inner">
            <Cloud className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black tracking-tight text-white">Cloud Settings</h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 bg-blue-500/20 text-blue-300 border-blue-500/40">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                Google Drive Cloud Backup
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Secure Google Drive cloud backups with one-click offline JSON and multi-sheet Excel archive export.
            </p>
          </div>
        </div>

        {/* Quick Offline Export Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => {
              backupService.downloadOfflineJsonArchive();
              setFeedback({
                type: 'success',
                message: 'Offline JSON archive exported successfully.',
              });
              setTimeout(() => setFeedback(null), 3500);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition shadow cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Offline JSON Archive</span>
          </button>

          <button
            onClick={() => {
              backupService.downloadOfflineExcelArchive();
              setFeedback({
                type: 'success',
                message: 'Offline Excel workbook exported successfully.',
              });
              setTimeout(() => setFeedback(null), 3500);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-900/20 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Offline Excel Workbook (.xls)</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 animate-in fade-in ${
            feedback.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Google Drive Backup Component */}
      <GoogleDriveBackupSection />
    </div>
  );
};
