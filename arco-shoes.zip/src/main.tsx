import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import './services/pwaService.ts';
import { registerSW } from 'virtual:pwa-register';

// Register PWA service worker with auto-update safely
if ('serviceWorker' in navigator && typeof window !== 'undefined' && window.location.protocol.startsWith('http')) {
  try {
    registerSW({
      immediate: true,
      onNeedRefresh() {
        console.log('[PWA] New application version detected, ready for refresh.');
      },
      onOfflineReady() {
        console.log('[PWA] ARCO SHOES is ready for offline and desktop execution.');
      },
      onRegisterError(error) {
        console.warn('[PWA] Service Worker registration skipped or restricted in dev preview:', error);
      },
    });
  } catch (err) {
    console.warn('[PWA] Service Worker registration skipped in current frame context:', err);
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
